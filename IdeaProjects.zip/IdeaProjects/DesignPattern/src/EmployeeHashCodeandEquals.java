import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class EmployeeHashCodeandEquals {
    Long id;
    String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EmployeeHashCodeandEquals(Long id, String name) {
        this.id = id;
        this.name = name;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmployeeHashCodeandEquals that = (EmployeeHashCodeandEquals) o;
        return Objects.equals(id, that.id) && Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }

    public static void main(String[] args) {
        System.out.println("Previously it was ->  Hash code Before 1791741888 and 1595428806");
        System.out.println("Output ->  false ");
        System.out.println("*********************************************************************");
        EmployeeHashCodeandEquals ab1 = new EmployeeHashCodeandEquals(1l,"Nishith");
        EmployeeHashCodeandEquals ab2 = new EmployeeHashCodeandEquals(1l, "Nishith");

        Object ab1hashcode = ab1.hashCode();
        Object ab2hashcode = ab2.hashCode();



        System.out.println("Hash code Before " +  ab1hashcode + " and " + ab2hashcode);

        Boolean istrue = ab1.equals(ab2);
        System.out.println("Output -> " + istrue);


        Set<EmployeeHashCodeandEquals> s1 = new HashSet<>();
        s1.add(ab1);
        s1.add(ab2);

        System.out.println("Previously it was -> [EmployeeHashCodeandEquals@6acbcfc0, EmployeeHashCodeandEquals@5f184fc6]");
        System.out.println("Output -> [EmployeeHashCodeandEquals@6acbcfc0, EmployeeHashCodeandEquals@5f184fc6] is absence of hashcode ");
        System.out.println("*********************************************************************");

        System.out.println("Now as per the latest if hascode is applied ");

        System.out.println("S1 -> " + s1);



    }
}
