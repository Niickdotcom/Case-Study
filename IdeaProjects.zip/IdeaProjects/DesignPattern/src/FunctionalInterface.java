

interface FI1{

    void absMethod();
    default void defaultMethod(){
        System.out.println("abcd");
    }
}

interface FI2{
    void absMethod();
    default void defaultMethod(){
        System.out.println("abcd");
    }
}
public class FunctionalInterface implements FI1, FI2{

    public static void main(String[] args) {

    }

    @Override
    public void absMethod() {

    }

    @Override
    public void defaultMethod() {
        FI2.super.defaultMethod();
    }
}
