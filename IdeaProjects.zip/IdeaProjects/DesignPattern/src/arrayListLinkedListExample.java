import java.util.ArrayList;
import java.util.LinkedList;

public class arrayListLinkedListExample {

    public static void main(String[] args) {

        ArrayList<String> student = new ArrayList<>();
        student.add("Alice");
        student.add("Bob");
        student.add("Charlie");


        System.out.println("Stiudent at index" + student.get(0));


        LinkedList<String>  student1 = new LinkedList<>();
        student1.addLast("Charlie");
        student1.addFirst("Bob");
        student1.addFirst("Alice");

        System.out.println("Adding randomly -> " + student1);

    }
}
