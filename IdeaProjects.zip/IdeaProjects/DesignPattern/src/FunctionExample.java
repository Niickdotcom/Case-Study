import java.util.function.Function;


interface  myInterface{
    Integer addition(int a,int b, int c);
}


public class FunctionExample implements  myInterface {

    public static void main(String[] args) {

//        myInterface add = (a,b,c) -> a + b + c;
//        System.out.println(add.addition(1,2,4));

        FunctionExample abc = new FunctionExample();
        Integer result = abc.addition(1,2,4);
        System.out.println(result);

    }

    @Override
    public Integer addition(int a, int b, int c) {
        return  a + b +c;
    }
}
