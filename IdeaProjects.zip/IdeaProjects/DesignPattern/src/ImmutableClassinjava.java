import java.util.Collections;
import java.util.List;


public final class ImmutableClassinjava {


    private  int Id;
    private  String name;
    private List<ImutableEmployee> employeeref;

    public String getName(){
        return name;
    }

    public int getId(){
        return Id;
    }

    public List<ImutableEmployee> getEmployeeref() {
        return Collections.unmodifiableList(getEmployeeref()) != null ? Collections.unmodifiableList(getEmployeeref()) : Collections.emptyList();
    }
}
