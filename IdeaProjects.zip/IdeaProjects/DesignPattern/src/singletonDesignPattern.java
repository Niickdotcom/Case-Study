import java.lang.reflect.Constructor;

public class singletonDesignPattern {
    //Multiple ways to write singleton pattern as
    // Eager Initialization
    // Lazy Initialization
    // Thread Safe (Synchronized method)
    // Double check locking



    private  singletonDesignPattern(){
    }


    private static singletonDesignPattern instance;

    //Lazy
    private static singletonDesignPattern getInstance(){
        if (instance == null) {
            synchronized (singletonDesignPattern.class) {
                if (instance == null) {
                    instance = new singletonDesignPattern();
                }
            }
        }
        return  instance;

    }

    private String getname(){
        return  "HelloWorld";
    }

    public static void main(String[] args) {
        /*singletonDesignPattern s1 = singletonDesignPattern.getInstance();
        System.out.println(s1.getname());

        singletonDesignPattern s2 = new singletonDesignPattern();
        System.out.println(s2.getname());*/

        /*Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                singletonDesignPattern s1 = singletonDesignPattern.getInstance();
                System.out.println(s1.hashCode());
            }
        });

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                singletonDesignPattern s2 = singletonDesignPattern.getInstance();
                System.out.println(s2.hashCode());
            }
        });

        t1.start();
        t2.start();*/
        singletonDesignPattern s1 = singletonDesignPattern.getInstance();
        singletonDesignPattern s2 =null;
       Constructor<singletonDesignPattern> constructor;
//        constructor = singletonDesignPattern.class.getDeclaredConstructors();
//        constructor
    }
}
