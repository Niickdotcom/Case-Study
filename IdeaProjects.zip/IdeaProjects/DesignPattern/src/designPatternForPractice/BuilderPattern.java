package designPatternForPractice;

public class BuilderPattern {

    private  String bread;
    private String dress;

    public BuilderPattern(String bread) {
        this.bread = bread;
    }

    public BuilderPattern(String bread, String dress){
        this(bread);
        this.dress = dress;
    }

    public String getBread() {
        return bread;
    }

    public String getDress() {
        return dress;
    }

    @Override
    public String toString() {
        return "BuilderPattern{" +
                "bread='" + bread + '\'' +
                ", dress='" + dress + '\'' +
                '}';
    }

    public static void main(String[] args) {
        BuilderPattern sss = new BuilderPattern("AAAA");
        BuilderPattern sss1 =  new BuilderPattern("PPPPP","BBB");

        System.out.println(sss);
        System.out.println(sss1);
    }
}
