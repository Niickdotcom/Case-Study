package designPatternForPractice;

public class SingletonDesignPattern {

    /*
    //Eger Loadeded
   private static SingletonDesignPattern instance = new SingletonDesignPattern();
   private SingletonDesignPattern(){
   }
   public  static SingletonDesignPattern getInstance(){
       return instance;
   }


    public static void main(String[] args) {
        SingletonDesignPattern ss = SingletonDesignPattern.getInstance();
        System.out.println(ss);
    }

    */


    /*
//    Lazy Loaded
private static SingletonDesignPattern instance = null;
    private SingletonDesignPattern(){
    }
    public  static SingletonDesignPattern getInstance(){
        if(instance == null){
            instance = new SingletonDesignPattern();
        }
        return instance;
    }


    public static void main(String[] args) {
        SingletonDesignPattern ss = SingletonDesignPattern.getInstance();
        System.out.println(ss);
    }


     */



   /* //Thread Safe
    private static SingletonDesignPattern instance = null;
    private SingletonDesignPattern(){
    }
    public  static synchronized SingletonDesignPattern getInstance(){
       if(instance == null){
           instance = new SingletonDesignPattern();
       }
       return instance;
    }

    public static void main(String[] args) {
        SingletonDesignPattern ss = SingletonDesignPattern.getInstance();
        System.out.println(ss);
    }*/


    //Thread safe with volating

    private static SingletonDesignPattern instance = null;
    private SingletonDesignPattern(){
    }
    public  static SingletonDesignPattern getInstance(){
        if(instance == null){
            instance = new SingletonDesignPattern();
        }
        return instance;
    }

    public void showMessage() {
        System.out.println("Singleton instance: " + this);
    }


    public static void main(String[] args) {
        // Create multiple threads to test thread safety
        Runnable task = () -> {
            SingletonDesignPattern singleton = SingletonDesignPattern.getInstance();
            singleton.showMessage();
        };

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);
        Thread t3 = new Thread(task);

        t1.start();
        t2.start();
        t3.start();
    }



}
