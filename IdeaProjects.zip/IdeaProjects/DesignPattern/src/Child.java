import java.awt.*;

class Parent {
    
    Parent(){
        this("Constructor"); // First this will call
        System.out.println("Parent Class Default Constructor 1"); //This will print Second
    }


    public Parent(String s) {
        System.out.println("Parent Class Param 2" + s); //This will print first
    }
}

public class Child extends Parent{
    
    Child(){
        this("Constructor");
        System.out.println("Child Class Default Constuctor 1"); // This will Print 4
    }

    Child(String s) {
        System.out.println("Child Class Param Constuctor 2" + s); //This will print 3
    }


    public static void main(String[] args) {
        Child obj = new Child();
    }
}
