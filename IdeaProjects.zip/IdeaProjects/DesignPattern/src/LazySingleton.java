public class LazySingleton {
    //
    private LazySingleton(){

    }

    public static LazySingleton instance = new LazySingleton(); // Egerly Intance





}
