import java.awt.*;

class Parent1 {

    Parent1(){
//        super(); // First this will call
        System.out.println("Parent Class Default Constructor 1");//this will get skipped
    }


    public Parent1(String s) {
        System.out.println("Parent Class Param 2" + s); //This will print 1
    }
}

public class Child1 extends Parent1{

    Child1(){
        super("Constructor"); //This will call directly this parent class cons
        System.out.println("Child Class Default Constuctor 1");  // This will prit 2
    }

    Child1(String s) {
        System.out.println("Child Class Param Constuctor 2" + s);
    }


    public static void main(String[] args) {
        Child1 obj = new Child1();
    }
}
