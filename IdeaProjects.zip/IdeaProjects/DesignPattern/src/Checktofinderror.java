public class Checktofinderror {

    void anyMethod(){

    }

}
