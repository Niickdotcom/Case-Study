public class ImutableEmployee {

    public int empid;
    public int empname;

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public int getEmpname() {
        return empname;
    }

    public void setEmpname(int empname) {
        this.empname = empname;
    }
}
