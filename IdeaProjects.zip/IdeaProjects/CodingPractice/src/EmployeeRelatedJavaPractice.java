import java.util.*;
import java.util.stream.Collectors;

public class EmployeeRelatedJavaPractice {


    public static void main(String[] args) {



        List<Employee> empadd =  new ArrayList<>();

        Employee emp = new Employee();
        emp.setId(1);
        emp.setName("Nishith");
        emp.setGender("Male");
        emp.setAge(28l);
        emp.setSalary(10.0);
        emp.setRating(4);
        empadd.add(emp);


        Employee emp1 = new Employee();
        emp1.setId(2);
        emp1.setName("Poo");
        emp1.setGender("Female");
        emp1.setAge(24l);
        emp1.setSalary(12.0);
        emp1.setRating(3);
        empadd.add(emp1);

        Employee emp2 = new Employee();
        emp2.setId(3);
        emp2.setName("Dev");
        emp2.setGender("male");
        emp2.setAge(20l);
        emp2.setSalary(9.0);
        emp2.setRating(4);
        empadd.add(emp2);


        Employee emp3 = new Employee();
        emp3.setId(4);
        emp3.setName("Ram");
        emp3.setGender("male");
        emp3.setAge(21l);
        emp3.setSalary(20.0);
        emp3.setRating(1);
        empadd.add(emp3);

        Employee emp4 = new Employee();
        emp4.setId(4);
        emp4.setName("Rshat");
        emp4.setGender("male");
        emp4.setAge(21l);
        emp4.setSalary(20.0);
        emp4.setRating(2);
        empadd.add(emp4);


//        Find the count of male and female employees present in the organization.
         findmaleandfemalewhopisggreagterthan20(empadd);
         secondhighestage(empadd);
         onlySecondheightageofmalecandidate(empadd);
         printAllNameAgeGreaterThe20(empadd);
         printEmployeSalarsamesortonbaseofrating(empadd);
         findMaximumAgeOfEmployee(empadd);
         findAverageAgeofMaleandFemalEmployee(empadd);
         printtheEmmployeeinEachRating(empadd);
         printtheEmployeewhereagelessthan20andgreatthat22(empadd);
         printtheEmployeewhohashightstnoofrating(empadd);
        thirdHighestSalary(empadd);
        //Find list of Designation from given employee list,
        findlistofgender(empadd);
        nameindescOrder(empadd);
        findemplbydeparmentandsecondhighestsala(empadd);
        checktheString();

         


    }

    private static void checktheString() {

        String s1 = new String("Hello");
        String s2 = "Hello";


        System.out.println("s1 == s3 "  + s1 == s2);
        System.out.println("s1.equals s2 " + s1.equals(s2));


    }

    private static void findemplbydeparmentandsecondhighestsala(List<Employee> empadd) {

        Optional<Double> secondHighestSala =
                empadd.stream()
                        .filter(e -> e.getRating().equals(1))
                        .map(Employee::getSalary)
                        .sorted(Comparator.reverseOrder())
                        .findFirst();

        System.out.println("second heig " + secondHighestSala);

    }

    private static void nameindescOrder(List<Employee> empadd) {

        List<String> reverseorderName =
                empadd.stream().sorted(Comparator.comparing(Employee::getName).reversed())
                        .map(Employee::getName).toList();

        System.out.println("Reverse name " + reverseorderName);


    }

    private static void findlistofgender(List<Employee> empadd) {

        List<String> abc = empadd.stream().map(Employee::getGender).toList();
        System.out.println(abc);
    }

    private static void thirdHighestSalary(List<Employee> empadd) {

        Optional<Employee> thirdhighestsala
                = empadd.stream().sorted(Comparator.comparingDouble(Employee::getSalary)).skip(2).findFirst();

        System.out.println("thrid highest " + thirdhighestsala);
    }

    private static void printtheEmployeewhohashightstnoofrating(List<Employee> empadd) {

//        Find the department name which has the highest number of employees.

        String EMPLOYENAME = empadd.stream().sorted(Comparator.comparingLong(Employee::getRating).reversed()).map(
                Employee::getName
                ).findFirst().get();

        System.out.println("Employee Name  ->  " + EMPLOYENAME);

    }

    private static void printtheEmployeewhereagelessthan20andgreatthat22(List<Employee> empadd) {

        List<Employee> agegreaterandlessthan20 = empadd.stream().filter(Employee -> Employee.getAge() < 20 || Employee.getAge() > 22).collect(Collectors.toList());
        System.out.println("Age Greater than 20 and less than 20 " +agegreaterandlessthan20);

    }

    private static void printtheEmmployeeinEachRating(List<Employee> empadd) {

        Map<Integer, Long> groupingByEmployee =
        empadd.stream().collect(Collectors.groupingBy(Employee::getRating, Collectors.counting()));

        System.out.println(groupingByEmployee);


    }

    private static void findAverageAgeofMaleandFemalEmployee(List<Employee> empadd) {

      Map<String, Double> averageAgeofgender =   empadd.stream().filter(ee -> ee.getGender().equals("male") || ee.getGender().equals("female")).collect(
                Collectors.groupingBy(ss -> ss.getName(), Collectors.averagingLong(Employee::getAge))
        );

        System.out.println(" Average Age - > " + averageAgeofgender);

    }

    private static void findMaximumAgeOfEmployee(List<Employee> empadd) {

       Employee maxmumAgeofEmp =  empadd.stream().max(Comparator.comparingLong(Employee::getAge)).get();
        System.out.println( " Maximum Age of Employee " +maxmumAgeofEmp);

    }

    private static void printEmployeSalarsamesortonbaseofrating(List<Employee> empadd) {


      Optional<Employee> printEmpwitRating =  empadd.stream().distinct().sorted(Comparator.comparingDouble(Employee::getSalary).thenComparingInt(
                Employee::getRating
        ).reversed()).findFirst();

     System.out.println( "OPPP -> " +  printEmpwitRating);


        List<Employee> maxprintEmpwitRating =  empadd.stream().max(Comparator.comparingDouble(Employee::getSalary)
                .thenComparingInt(Employee::getRating)).map(List::of).get();

        System.out.println("MaxEmpwithRating" +maxprintEmpwitRating);








    }

    private static void printAllNameAgeGreaterThe20(List<Employee> empadd) {

        List<String> ListofEmployename =
                empadd.stream().filter(emmp -> emmp.getAge() <= 20).map(Employee::getName).toList();

        System.out.println("List of EMployee name " + ListofEmployename );



    }

    private static void onlySecondheightageofmalecandidate(List<Employee> empadd) {


        Employee secondHighest = empadd.stream().filter(ss -> ss.getGender().equals("male")).sorted(Comparator.comparing(Employee::getAge).reversed()).skip(1).findFirst().get();
        System.out.println(secondHighest);


//         Employee byComparator = empadd.stream().collect(Collectors.groupingBy(
//                Employee::getGender, (Comparator.comparingLong(Employee::getAge).reversed()), Collectors.toList()));

        Map<String, List<Employee>> groupedSorted = empadd.stream()
                .collect(Collectors.groupingBy(
                        Employee::getGender,
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                list -> list.stream()
                                        .sorted(Comparator.comparingLong(Employee::getAge).reversed())
                                        .collect(Collectors.toList())
                        )
                ));

        System.out.println(groupedSorted);


    }

    private static void secondhighestage(List<Employee> empadd) {

       Employee aaa = empadd.stream().sorted(Comparator.comparing(Employee::getAge).reversed()).skip(1).findFirst().get();
        System.out.println("EMployee " + aaa.toString());





    }

    private static void findmaleandfemalewhopisggreagterthan20(List<Employee> empadd) {


        List<Employee> nameofempagemore20 =

                empadd.stream().filter(e -> e.getGender().equals("Male")
                || e.getGender().equals("Female") && e.getAge() > 20).toList();

        nameofempagemore20.forEach(ss -> System.out.println("ame of Emp more 20 " +ss));




//        Given a list of Employee object having name and salary fields,
//        find third highest salaried employee using java 8 stream



    }

}
