import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ConvertHashMapinJava {
    public static void main(String[] args) {

        Integer[] soq = {5,3,2,6,5,1,2,3,2};

        Map<Integer,Long> countOfNumber = Arrays.stream(soq).collect(Collectors.groupingBy(i -> i,Collectors.counting()));
        System.out.println(countOfNumber);



        String[] flower = {"lily","hibiscus","jasmine","rose",null};

        Map<String,Integer> flowermap = Arrays.stream(flower).filter(str -> str != null).collect(Collectors.toMap(
                wrd -> wrd, wrd -> wrd.length()
        ));

        System.out.println("flowermap -> " + flowermap);


        List<String> strList = new ArrayList<>();
        strList.add("lily");
        strList.add("hibiscus");
        strList.add("jasmine");
        strList.add("rose");
        strList.add(null);


     String flowermaxlength =    strList.stream().filter(str1-> str1 != null).max(Comparator.comparingInt(
                String::length
        )).get();

        System.out.println(flowermaxlength);


        List<String> list=Arrays.asList("sita","Jeet","Rama","Laxman");
//        sort based on their length

        List<String> stringBasedonLength = list.stream().
                    sorted(Comparator.comparingInt(String::length)).toList();

        System.out.println("List sort output -> " + stringBasedonLength);


        HashMap<Integer,String> h = new HashMap<>();
        h.put(1,"test");
        h.put(1,"Retest");
        h.put(2,"AgainTest");
        System.out.println(h);


        String s1 = "listen";
        String s2 = "silent";


//        Boolean isanagram

       Boolean isanagram1 =  Arrays.equals(IntStream.range(0,s1.length()).sorted().boxed().toArray(),
        IntStream.range(0,s2.length()).sorted().boxed().toArray());


        Boolean isanagram2 = Arrays.equals(s1.chars().sorted().toArray(),s2.chars().sorted().toArray());


        System.out.println("Is -> Ana1 -> " + isanagram1);
        System.out.println("Is -> Ana2 -> " + isanagram2);


        String s11="test";
        String s21="test";
        String s31=new String("test");
        String s41 = new String("test");
        System.out.println(s11.equals(s21));
        System.out.println(s11.equals(s31));
        System.out.println(s21==s31);
        System.out.println(s31 == s41);



        Consumer<String> abc = str -> System.out.println(str);
        abc.accept("abc");


        Supplier<Integer> pqr = () -> (int) (Math.random() * 100);
        System.out.println(pqr.get());


        Predicate<String> xyz = str11 -> str11.length()>5;
        System.out.println(xyz.test("Abcd"));


        Function<String,String> zyzy = str -> str.toUpperCase();
        System.out.println(zyzy.apply("abcd"));





//        palindrome of int = 565

        int n = 565;
        int temp = n;
        int reverse=0;

        while (n != 0){

           int digit =  n % 10;
            reverse = reverse * 10 + digit;
            n /= 10;
        }

        System.out.println(reverse);

        if (temp == reverse){
            System.out.println("is palindrome");
        }


        HashMap<String,String> hashMap = new HashMap<>();
        hashMap.put("rohit","mumbai");
        hashMap.put("prasad","mumbai");
        hashMap.put("vasil","gujrat");
        hashMap.put("vasil","navi mumbai");


        List<String> list11 = hashMap.entrySet().stream().filter(s -> s.getValue().equals("mumbai")).map(
                str -> str.getKey()
        ).toList();

        System.out.println(list11);





    }
}
