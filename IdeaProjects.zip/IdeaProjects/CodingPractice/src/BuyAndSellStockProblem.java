import java.util.Map;

public class BuyAndSellStockProblem {

    public static void main(String[] args) {

        int[] numbers = {7,1,3,4,5,6,2};
        int minpricea = Integer.MAX_VALUE;
        int maxprice = 0;

        for(int price : numbers){
            if (price < minpricea){
                minpricea = price;
            } else  {
                int profit = price -  minpricea;

                if(profit > maxprice){
                    maxprice = profit;
                }
            }
        }
        System.out.println(maxprice);
        
        practicingday1(numbers);
        highestElement();


    }

    private static void highestElement() {

        int[] arr = new int[] {1, 4, 2, 3, 14, 5, 6, 7};
        int first = 0;
        int second = 0;

        for(int arrcheck : arr){

            if(first < arrcheck){
                second = first;
                first = arrcheck;
            } else if(second < arrcheck){
                second = arrcheck;
            }
        }

        System.out.println("First -> " + first);
        System.out.println("Second -> " +second);

    }


    private static void practicingday1(int[] numbers) {

        int minimunprice = Integer.MAX_VALUE;
        int maximumprince = 0;


        for(int price : numbers){
            if(price < minimunprice){
                minimunprice = price;
            } else {
                int profit = price - minimunprice;

                if(profit > maximumprince){
                    maximumprince = profit;
                }
            }
        }

        System.out.println(maximumprince);



    }
}
