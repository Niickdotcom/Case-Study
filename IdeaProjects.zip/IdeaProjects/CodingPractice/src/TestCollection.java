import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TestCollection {

    public static void main(String[] args) {

    Map<String,String> cityCode = new HashMap<String,String>();
    cityCode.put("India","Kolkata");
    cityCode.put("Russia","Moscow");
    cityCode.put("USA","NewYork");

        Iterator<String> iterator = cityCode.keySet().iterator();

        while (iterator.hasNext()){
            String country = iterator.next();
            System.out.println("Country  " + country);
            if("India".equals(country)){
                cityCode.put("India","Delhi");
//                cityCode.put("Pakistan","Lahore");
            }
            System.out.println("County " + country + ", Capitol " + cityCode.get(country));
        }


    }
}
//Three Scenario

/*
1) IT will Thorw a Concurrent Modification Exception because adding a new Record, So adding the exsiting record
and updating its value so it will give the proper result
2) for preventing concurrent modification exception we can implement ConcurrentHashMap while initialization
So it helps us to add the records at the time of iteration
3)
 */