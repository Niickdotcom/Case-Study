import java.util.*;
import java.util.stream.Collectors;

public class StringRelateduestion {
    public static void main(String[] args) {


        List<String> words = Arrays.asList("AA","BB","CC","AA");
        //op AA = 2, BB=1,CC=1


        Map<String, Long> countingofword = words.stream().collect(Collectors.groupingBy(
                i -> i,Collectors.counting()
        ));

        System.out.println("Counting char " +countingofword);

        System.out.println();
        List<String> digitstartingChar = Arrays.asList("5AA","BB","1CC","AA");
        List<String> checkliststartingfromdigit =
                digitstartingChar.stream().filter(s -> Character.isDigit(s.charAt(0))).toList();

        System.out.println("is digit starting " +checkliststartingfromdigit);



        List<String> names = Arrays.asList("Nishith","Mehta", "Nishith");

        //Remove the dublicate
        List<String> removedublicate =
                names.stream().distinct().toList();

        System.out.println("using distinct " + removedublicate);

        Set<String> setname = new HashSet<>();
        List<String> usingset = names.stream().filter(s -> setname.add(s)).toList();

        System.out.println("using set " + usingset);


        System.out.println();

        Integer[] numbers = {4,5,3,9,1,2,10,8,3,4,};
        //Find the third largest element

        Optional<Integer> thirdLargestElement =
                Arrays.asList(numbers).stream().sorted(Comparator.reverseOrder()).skip(2).findFirst();

        System.out.println("third largest element -> " + thirdLargestElement);


        String letters = "TyatYTHGffffggg";

        // siplit the capital and small

        String uppercaseletter =
                letters.chars().mapToObj(c -> (char) c).filter(Character::isUpperCase).map(s -> String.valueOf(s)).collect(
                        Collectors.joining()
                );

        System.out.println("Upper case letter -> " + uppercaseletter);


        String lowercaseletter =
                letters.chars().mapToObj(c -> (char) c).filter(Character::isLowerCase).map(s -> String.valueOf(s))
                        .collect(Collectors.joining());

        System.out.println("lower case letter -> " + lowercaseletter);
    }
}
