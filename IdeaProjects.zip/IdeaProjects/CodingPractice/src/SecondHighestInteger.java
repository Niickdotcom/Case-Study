import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

public class SecondHighestInteger {

    public static void main(String[] args) {


        int[] withoutusingjava8SecondHighest = {1,3,9,5,2,6,2};

        //without java 8
        int firstlargest = 0;
        int secondlargest = 0;
        for(int abc : withoutusingjava8SecondHighest){

            if(firstlargest < abc){
                secondlargest = firstlargest;
                firstlargest = abc;
            } else if(secondlargest < abc){
                secondlargest = abc;
            }
        }
        System.out.println(secondlargest);

        List<String> listOfStrings = Arrays.asList("Java", "Python", "C#", "HTML", "Kotlin", "C++", "COBOL", "C");
        List<String> compare = listOfStrings.stream().sorted(Comparator.comparingInt(String::length)).toList();
        System.out.println("compare " + compare);

        Pallindrome();

    }

    private static void Pallindrome() {

        String name = "mom";

        Boolean ispallindrome = IntStream.range(0, name.length() / 2).allMatch(
                i -> name.charAt(i) == name.charAt((name.length() - 1 - i))
        );
        System.out.println(" IsPallindrome -> " + ispallindrome);


        Boolean Pallindrom  = IntStream.range(0,name.length()/2).allMatch(
                i -> name.charAt(i) == name.charAt((name.length()-1-i))
        );
        System.out.println(Pallindrom);

        int num = 565;
        int tepnum = num;
        int revrese = 0;

        while(tepnum != 0){
            int temp = tepnum % 10;
            revrese = revrese * 10  + temp;
            num /=10;
        }
        System.out.println("reverse " +revrese);
        System.out.println("num " +num);
        System.out.println(num == revrese);
        if(num == revrese){
            System.out.println("is palindrome " + num);
        }




    }
}
