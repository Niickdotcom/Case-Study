import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class sumofSquarewithEvenNumber {

    public static void main(String[] args) {

//        Sum of squares of even numbers.
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);//4+16=20

        Optional<Integer> squarerootofecvenno =
                numbers.stream().filter(s -> s%2==0).map(a -> a*a).reduce((a,b) -> a + b);

        System.out.println("sum " + squarerootofecvenno);


        Double collect = numbers.stream().filter(s1 -> s1 % 2 == 0).collect(Collectors.averagingInt(Integer::intValue));
        System.out.println(collect);



        List<String> words = Arrays.asList("array", "apple", "rat");

        Set<String> abc = new HashSet<>();

      String aa = String.valueOf(words.stream().collect(Collectors.groupingBy(s -> s, LinkedHashMap::new,Collectors.counting())));

        System.out.println(aa);


      String wrd = words.stream().map(ss -> ss.toCharArray()).collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new,Collectors.counting()))
                      .entrySet().stream().filter(ss -> ss.getValue() > 1).map(str -> String.valueOf(str.getKey())).collect(Collectors.joining());

        System.out.println((wrd));
        System.out.println("sssss");
        System.out.println(words.stream().map(ss -> ss.toCharArray()));



        String str = "i am soham";// I Am Soham

        String capToUpp = Arrays.stream(str.split(" "))
                .map(wrds -> Character.toUpperCase(wrds.charAt(0)) +
                        wrds.substring(1).toLowerCase())
                .collect(Collectors.joining(" "));

        System.out.println(capToUpp);

    }
}
