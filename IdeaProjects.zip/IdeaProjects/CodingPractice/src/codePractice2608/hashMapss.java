package codePractice2608;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class hashMapss<Stirng, S> implements Map<String, Stirng> {
    @Override
    public int size() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public boolean containsKey(Object key) {
        return false;
    }

    @Override
    public boolean containsValue(Object value) {
        return false;
    }

    @Override
    public Stirng get(Object key) {
        return null;
    }

    @Override
    public Stirng put(String key, Stirng value) {
        return null;
    }

    @Override
    public Stirng remove(Object key) {
        return null;
    }

    @Override
    public void putAll(Map<? extends String, ? extends Stirng> m) {

    }

    @Override
    public void clear() {

    }

    @Override
    public Set<String> keySet() {
        return Set.of();
    }

    @Override
    public Collection<Stirng> values() {
        return List.of();
    }

    @Override
    public Set<Entry<String, Stirng>> entrySet() {
        return Set.of();
    }

    @Override
    public boolean equals(Object o) {
        return false;
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
