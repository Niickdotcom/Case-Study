package codePractice2608;

public class atmMethods {
    int count = 0;
    int countprevious;

    public String withdrawamt(int pin, double amount) {

        String message = "";

        if (pinmatch(pin)) {
            message = "Withdrawn: " + amount;
        }
        return message;
    }


    private boolean pinmatch(int pin) {

        int currpin = 1234;

        if (pin == currpin) {
            return true;
        }

        return false;

    }

    // deposit(pin,amount);

    public String changePin(int pin, int latestpin) {

        String chngPinMsg = "";

        if (pinmatch(pin)) {
            ATMCLASS abcd = new ATMCLASS();
            abcd.setPin(latestpin);
            chngPinMsg = "PIN Changed";
        } else {
            chngPinMsg = "Pin Not match";
        }

        return chngPinMsg;
    }


    public  String withdrawamtpin(int pin, int atempt){
        String messgae = "";

        if (!pinmatch(pin)) {
            if (atempt == 3) {
                messgae = "Account Locked";
            } else {
                messgae = "Incorrect PIN";

            }
        }

        return messgae;
    }


}

