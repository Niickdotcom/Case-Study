package codePractice2608;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class Emp {


    /*
    Write Employee bean class and sort employees by their names
     */



    String empName;
    String empAddress;

    public Emp(String empName, String empAddress) {
        this.empName = empName;
        this.empAddress = empAddress;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpAddress() {
        return empAddress;
    }

    public void setEmpAddress(String empAddress) {
        this.empAddress = empAddress;
    }

    @Override
    public String toString() {
        return "EMployeee{" +
                "empName='" + empName + '\'' +
                ", empAddress='" + empAddress + '\'' +
                '}';
    }
}


public class EMployeee {

    public static void main(String[] args) {

        Emp e1 = new Emp("Nishiht","mehta");
        Emp e2 = new Emp("Akash","Joshi");
        Emp e3 = new Emp("Varun","Vyas");


        List<Emp> n = new ArrayList<>();
        n.add(e1);
        n.add(e2);
        n.add(e3);

        System.out.println(" prr " +n);


        n.sort(Comparator.comparing(Emp::getEmpName));
        System.out.println(n);



    }



}
