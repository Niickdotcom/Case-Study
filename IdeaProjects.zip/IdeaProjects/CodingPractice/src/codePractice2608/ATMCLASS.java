package codePractice2608;

public class ATMCLASS {

    private int pin;
    private double balance;
    private int attempts;

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getAttempts() {
        return attempts;
    }

    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }


    public static void main(String[] args) {
        atmMethods meths = new atmMethods();

      String op =   meths.withdrawamt(1234,1000);
        System.out.println("op -> " + op);

      String op1 =   meths.withdrawamt(1111, 2000);
        System.out.println("op -> " + op1);


        String op2 = meths.withdrawamtpin(1111,3);
        System.out.println("op2 -> " + op2);


    }
}
