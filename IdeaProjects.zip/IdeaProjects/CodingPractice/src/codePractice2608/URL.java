package codePractice2608;

public class URL {

    public static void main(String[] args) {

    }
}
