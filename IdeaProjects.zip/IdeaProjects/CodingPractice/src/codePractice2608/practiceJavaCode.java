package codePractice2608;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class practiceJavaCode {

    public static void main(String[] args) {


        printwith1injava();
        evennumberfromUsingStream();
        convertedtocommaseparatedString();
        findthecharacteroccaranceinstring();
        removedublicatecount();
        findthefirstnonrepertingcharacter();
        findmaxlenghtusingStreamAPI();
        sorttheelementinascanddscusingstream();
        pallindromeofanumber();
        remocvethevowels();
        buySellStockProblem();
        consverStringtoCamclecase();
        findMaxLengthofElement();
        findthetotallenghtofwordinaString();
        FunctionalPrograming();
        countingString();
        reversewordwise();
//        squreandreturn1or0();
        hashmaptosotreuniqueelement();
        calculation();
        countoftheSentense();
        sortedtheString();
        sortingandmerging();
        comapringValue();
        differenceofarray();
        missingcharacterfromString();
        findoutsubstring();
        firstnonrepitingchar();
        armstrongnumber();
        strongnumber();


    }

    private static void strongnumber() {

        /*
        Check the given number is Strong number or not.
Strong number is a special number whose sum of factorial of digits is equal to the original number.
For example: 145 is strong number. Since, 1! + 4! + 5! = 145
         */


        int i = 145;



    }

    private static void armstrongnumber() {

        /*
        Print all Armstrong number between 1 to 1000.
An Armstrong number is a n-digit number that is equal to the sum of nth power of its digits. For example,
6 = 61 = 6
371 = 33 + 73 + 13 = 371
"Implement the method that provided numerator and denominator will return a string representing fraction's decimal form.
   * Some fractions in decimal form have cyclic decimal points.
   *
   * Examples:
   * 1/2 = 0.5
         */


        List<Integer> numb = new ArrayList<>();
        for(int i = 100;i<1000;i++){
            if(isarmstng(i)){
                numb.add(i);
            }

        }
        System.out.println(numb);


    }

    private static boolean isarmstng(int i) {

        int rev = 0;
        int temp = i;

        while(i != 0){

            int dig = i % 10;
            rev = rev * 10 + dig;
            i /= 10;

        }

        return  temp == rev;


    }

    private static void firstnonrepitingchar() {


        /*
        7.  First Non-repeated character from the String
Ex:
Input : { "array", "apple", "rat"}
Output: y,a,r
         */

        String[] words = {"array","apple","rat"};
        String appending ="";
        for(String s  : words){


            String nonrepeting =
                    s.chars().mapToObj(c -> (char) c)
                            .collect(Collectors.groupingBy(c -> c,LinkedHashMap::new, Collectors.counting()))
                            .entrySet().stream().filter(ss -> ss.getValue() == 1).map(str -> str.getKey())
                            .findFirst().map(String::valueOf).get();
            appending += nonrepeting;



        }
        System.out.println("non-> " + appending);



    }

    private static void findoutsubstring() {
        /*
        9. Find out unique substring of given length of string.
EX:
Input - (aab,2) , Output - aa, ab
Input- (aabc,2), Output - aa, ab,bc
Input -(abc,1), Output - a,b,c
         */

        String ss = "abc";
        int n = 1;

        StringBuilder str = new StringBuilder();
        String  combine="";
        Set<String> unique = new HashSet<>();
        for(int i = 0;i<=ss.length()-n;i++){
          combine  = ss.substring(i, i+n);
          System.out.println("combile -> " + combine);
          unique.add(combine);
        }


        System.out.println("Set unique->  " + unique);


    }

    private static void missingcharacterfromString() {

        /*
        10. Write a method that should return difference of characters (missing char from given string) between  given String and Input string.
     eg. Given String  = "abcdefghijklmnopqrstuvwxyz";
           Input String  = "Online test with GS client ";
         */

        String ss = "Online test with GS client";
        String ggss = "abcdefghijklmnopqrstuvwxyz";

        Set<Character> arr = ss.toLowerCase().chars()
                              .filter(Character::isLetter)
                                .mapToObj(c -> (char) c)
                                        .collect(Collectors.toSet());

        String missigChar = ggss.chars().
                mapToObj(c -> (char) c)
                        .filter( inp -> !arr.contains(inp))
                                .map(String::valueOf)
                                        .collect(Collectors.joining(""));



        System.out.println("Missiong characterv -> " + missigChar);

    }

    private static void differenceofarray() {


        /*
        12. Find the median of two sorted arrays of different size.
Example:
Input :
Array 1: 2 3 6 7 9
Array 2: -1 4 8 10  = 5
Output : 6
Hint: The final sorted array would be - 1, 2, 3, 4, 6, 7, 8, 9, 10 The 5th element of this array is 6.
         */


        int[] arr1 = {2,3,6,7,9};
        int[] arr2 = {-1,4,8,10};


        Integer arr1sum = Arrays.stream(arr1).reduce((a,b)-> a + b).getAsInt();
        Integer arr2sum = Arrays.stream(arr2).reduce((a,b) -> a + b).getAsInt();

        int diff = arr1sum - arr2sum;
        System.out.println(diff);


    }

    private static void comapringValue() {

//        Input: arr1 = [1,2,3,4,5], arr2 = [1,2,5,7,9], arr3 = [1,3,4,5,8]
//        Output: [1,5]

        int[] arr1 = {1,2,3,4,5};
        int[] arr2 = {1,2,5,7,9};
        int[] arr3 = {1,3,4,5,8};


//        while ()

    }

    private static void sortingandmerging() {

        /*
         Given two sorted arrays, the task is to merge them in a sorted manner .
        Example:1
Input: arr1[] = { 1, 3, 4, 5}, arr2[] = {2, 4, 6, 8}
Output: arr3[] = {1, 2, 3, 4, 4, 5, 6, 8}
Example 2:
Input: arr1[] = { 3,7,9,12,21}, arr2[] = {6,8,15,18,27}
Output: arr3[] = {3,6,7,8,9,12,15,18,21,27}
Example 3:
Input: arr1[] = { 3,7,9,-12,21,12}, arr2[] = {6,8,15,-18,27}
Output: arr3[] = {-18,-12,3,6,7,8,9,12,1521,27}
Time complexity: O(n1+n2) where n1 and n2 are size of each array.
         */

        int[] arr1 = { 3,7,9,-12,21,12};
        int[] arr2 = {6,8,15,-18,27};
       // Output: arr3[] = {1, 2, 3, 4, 4, 5, 6, 8}

       List<Integer> mergeandSort = Stream.concat(Arrays.stream(arr1).boxed(),
                Arrays.stream(arr2).boxed()).sorted().toList();

        System.out.println("Merge -> " + mergeandSort);


    }

    private static void sortedtheString() {


        List<String> input = Arrays.asList("Ajay", "Raja", "Keshav", "List", "Set", "Elephant", "Drone");
        String sortOrder = "TESARDLK";

        Map<Character,Integer> orderMap = new HashMap<>();
        for(int i =0;i<sortOrder.length();i++){
            orderMap.put(sortOrder.charAt(i),i);
        }

        System.out.println("sorted -> " + orderMap);

        input.sort((s1,s2) -> comparvalue(s1,s2,orderMap));

        System.out.println("Sorted -> " + input);

    }

    private static int comparvalue(String s1, String s2, Map<Character, Integer> orderMap) {
        int len = Math.min(s1.length(),s2.length());
        for(int i =0;i<len;i++){
            char c1  = Character.toUpperCase(s1.charAt(i));
            char c2  = Character.toUpperCase(s2.charAt(i));

            int w1 = orderMap.getOrDefault(c1,Integer.MAX_VALUE);
            int w2 = orderMap.getOrDefault(c2,Integer.MAX_VALUE);

            if(w1 != w2){
                return Integer.compare(w1,w2);
            }
        }
        return Integer.compare(s1.length(),s2.length());
    }

    private static void countoftheSentense() {

        String sentence =
                "Sunset is the time of day when our sky meets the outer space solar winds. There are blue, pink, and purple swirls, spinning and twisting, like clouds of balloons caught in a whirlwind. The sun moves slowly to hide behind the line of horizon, while the moon races to take its place in prominence atop the night sky. People slow to a crawl, entranced, fully forgetting the deeds that must still be done. There is a coolness, a calmness, when the sun does set.";

        Map<String,Long> grpCount =  Arrays.stream(sentence.split(" ")).sorted(Comparator.reverseOrder())
                .collect(Collectors.groupingBy(
                        i->i,LinkedHashMap::new, Collectors.counting()
                ));

        System.out.println(grpCount);

       Map<String,Long> max =  grpCount.entrySet().stream().filter(ss -> ss.getValue() > 1)
               .collect(Collectors.toMap(wr -> wr.getKey(), wr ->wr.getValue(),
                       (e1,e2) -> e1, LinkedHashMap::new));

        System.out.println(max);




    }

    private static void calculation() {

//        ** The total for this example would be 10 (2+0+1+1+1+0+5)."

        Integer[] aa = {2,0,1,1,1,0,5};

        Optional<Integer> sum = Arrays.stream(aa).reduce((a, b) -> a + b);
        System.out.println(sum);


    }

    private static void hashmaptosotreuniqueelement() {

        HashMap<Integer,String> h=new HashMap<>();
        h.put(1,"test");
        h.put(1,"Retest");
        h.put(2,"AgainTest");
        h.put(3,"AgainTest");

        System.out.println("--> " + h);


        HashMap<Integer,Set<String>> uniqueValues = new HashMap<>();
        for (Map.Entry<Integer, String> unq : h.entrySet()){
                Integer ss = unq.getKey();
                String ss1 = unq.getValue();

                uniqueValues.computeIfAbsent(ss, k -> new HashSet<>()).add(ss1);
        }

        System.out.println(uniqueValues);
    }

    private static void squreandreturn1or0() {

        int[] a = {1,2,3,4,5};
        int square = 0;
        for(int i = 0;i<a.length;i++){

            square = a[i] * a[i];
            matchme(a,square);
        }



        List<Integer> arr = Arrays.stream(a).map(s -> s * s).boxed().toList();
        System.out.println(arr);

        List<Integer> matchsss = arr.stream().filter(s -> a[s] == s).toList();
        System.out.println(matchsss);


    }

    private static void matchme(int[] a, int square) {
        int returnmatch = 0;
        for(int j = 0;j<a.length;j++){
            if(a[j] == square){
                returnmatch = a[j];
                System.out.println("return  = " + returnmatch);
            }
        }
    }

    private static void reversewordwise() {

        String name = "nishith hello";

      String revers = String.valueOf(Arrays.stream(name.split(""))
        .mapToInt(s -> s.charAt(0)).reduce((a,b) -> b - a));

        System.out.println(revers);


      String rev = String.valueOf(name.chars().mapToObj(c -> (char) c).reduce((p, q) -> (char) (q - p)));
        System.out.println("reve " + rev);

        String reversr = String.valueOf(Arrays.stream(name.split(""))
                .mapToInt(s -> s.charAt(0))
                .reduce((a,b) -> b - a));

        System.out.println(reversr);


        List<StringBuffer> wordrev = Arrays.stream(name.split(" "))
                .map(ss -> new StringBuffer(ss))
                .collect(Collectors.toList()).reversed();

        System.out.println(wordrev);


        hashMapss<String,String> ab = new hashMapss<>();


    }

    private static void countingString() {

        String words = "abkabiab";
        int count = 0;
        int index = 0;
        String target = "ab";
        System.out.println("aa");
        while ((index = words.indexOf(target,index)) != -1){
            count++;
            index += target.length();
        }

        System.out.println(count);

    }

    private static void FunctionalPrograming() {


        Consumer<String> ss = stst -> System.out.println(stst);
        ss.accept("Hello World");

        Supplier<Integer> aa = () -> (int) (Math.random() * 100);
        System.out.println(aa.get());

        Predicate<String> str = stst2 -> stst2.length() > 2;
        System.out.println(str.test("ANCDDD"));

        Function<Integer,Integer> cal =
                n -> (n * n);

        System.out.println(cal.apply(2));


        String letters =
                "i am nishith mehta";


        //Convert the first Letters as Captiatal


     String upString =    Arrays.stream(letters.split(" ")).
                map(str9 -> str9.substring(0,1).toUpperCase()
                 + str9.substring(1)).collect(Collectors.joining(" "));

        System.out.println(upString);





    }

    private static void findthetotallenghtofwordinaString() {


        String[] input = {"nishith","mehta","jobin","thomas","chinmay","bandekar"};

        Optional<String> maxString = Arrays.stream(input).max(Comparator.comparingInt(String::length)).stream().findFirst();
        System.out.println("Max String " + maxString);
    }

    private static void findMaxLengthofElement() {

        String words = "Helloooooo my name is nishith";
        String maxlenght =
                Arrays.stream(words.split(" "))
                                .max(Comparator.comparingInt(String::length)).get();

        System.out.println(maxlenght);






    }

    private static void consverStringtoCamclecase() {

        String word = "helloworld";

     String CamelCase =
             IntStream.range(0,word.length())
                             .mapToObj(i ->
                                     i == 5 ? String.valueOf(Character.toUpperCase(word.charAt(i)))
                                     : String.valueOf(word.charAt(i)))
                                     .collect(Collectors.joining());

        System.out.println("Camel Case " + CamelCase);


        String hardCode =

                IntStream.range(0, word.length())
                        .mapToObj(i -> i == 5 ?
                                String.valueOf(Character.toUpperCase(word.charAt(i)))
                                : String.valueOf(word.charAt(i))).collect(Collectors.joining());

        System.out.println(hardCode);



    }

    private static void buySellStockProblem() {
        int[] numbers = {7,1,3,4,5,6,2};

        Integer buyStock = Integer.MAX_VALUE;
        Integer sellStock  = 0;

        for(int st : numbers){
            System.out.println("macX value " + buyStock);
            if(st < buyStock){
                buyStock = st;
            } else {

                int diff = st - buyStock;


                if(diff > sellStock){
                    sellStock = diff; //2,3,4,5
                }

            }


        }

        System.out.println("Buy sotck -> " + buyStock);
        System.out.println("Sell sotck -> " + sellStock);



    }

    private static void remocvethevowels() {

        String name = "Nishtihmehta";
        String strVowel =   name.chars().mapToObj(c -> (char) c)
                .filter(ss -> String.valueOf(ss).matches("[aeiouAEIOU]"))
                .map(String::valueOf).collect(Collectors.joining());

        System.out.println("String With Vowels " + strVowel);


        //CountofVowelPresent
        Long countVowel = name
                .chars().mapToObj(c1 -> (char) c1)
                .filter(s1 -> String.valueOf(s1).matches("[aeiouAEIOU]"))
                .map(String::valueOf).count();

        System.out.println("count Vowel -> " + countVowel);

        Long countWithourVowel = name.chars()
                .mapToObj(c2 -> (char) c2)
                .filter(s2 -> !String.valueOf(s2).matches("[aeiouAEIOU]"))
                .map(String::valueOf).count();

        System.out.println("Count without Vowel -> " + countWithourVowel);




    }

    private static void pallindromeofanumber() {
        int aa = 151;

        int rev = 0;
        int temp = aa;
        while (aa != 0){
            int dig = aa % 10;
            rev = rev * 10 + dig;
            aa /= 10;
        }

        if(rev == temp){
            System.out.println("Is a Plliandrom");
        }



    }

    private static void sorttheelementinascanddscusingstream() {

        String[] arr = {"Green", "White", "Black", "Pink", "Orange", "Blue", "Champagne", "Indigo", "Ivory"};

        List<String> sortStringAsc = Arrays.stream(arr).sorted().toList();
        System.out.println("Sorting String Asc " + sortStringAsc );

        //Sorting String Based on Length
        List<String> sortBasedonLength  =
                Arrays.stream(arr).sorted(Comparator.comparingInt(String::length)).toList();
        System.out.println("Sorting String Based on Lenght " + sortBasedonLength);


        //ReturnMap for string and its Lenght

        Map<String,Integer> retunMapwithLengthCount =   Arrays.stream(arr).collect(Collectors.toMap(
                wrd -> wrd, wrd -> wrd.length()
        ));

        System.out.println("Retuning String With Its Count " + retunMapwithLengthCount);

        //Returning String With UpperCase

        List<String> toUpperCaseString = Arrays.stream(arr).map(str -> str.toUpperCase()).toList();
        System.out.println("StringwithUpperCase -> " + toUpperCaseString);

        //NonRepertingCharacterInStringArray
        String nonReperingInstring="";
        for(String ss : arr){
            nonReperingInstring
                    += Arrays.stream(ss.split("")).
            collect(Collectors.groupingBy( i-> i,LinkedHashMap::new,Collectors.counting()))
                    .entrySet().stream().filter(stn -> stn.getValue() == 1).findFirst()
                    .map(sn -> sn.getKey()).get();
        }

        System.out.println("NonRepetinginString " + nonReperingInstring);




    }

    private static void findmaxlenghtusingStreamAPI() {

        List<Integer> list = Arrays.asList(10,20,500,50,59,80,70,100,400,300);

        Optional<Integer> maxInterger = list.stream().sorted(Comparator.reverseOrder()).findFirst();
        System.out.println("maxInteeger -> " + maxInterger);

        Integer usingMax  = list.stream().max((s1,s2) -> s1.compareTo(s2)).get();
        System.out.println(usingMax);

        //NormalFlow
        Integer maxFirst = 0;
        Integer maxSecod = 0;


        for(Integer i : list){

            if(maxFirst < i){
                maxSecod = maxFirst;
                maxFirst = i;
            } else if(maxSecod < i){
                maxSecod = i;
            }

        }
        System.out.println("MaxFirst -> " + maxFirst);
        System.out.println("MaxSecond -> " + maxSecod);






    }

    private static void findthefirstnonrepertingcharacter() {

        //Java 8
        String name = "Nishith"; //Nst
       String java8countingofnonrep =  Arrays.stream(name.split("")).collect(Collectors.groupingBy(
                i -> i, LinkedHashMap::new,Collectors.counting()
        )).entrySet().stream().filter(ss -> ss.getValue() == 1).map(
                str -> str.getKey()
        ).collect(Collectors.joining());

        System.out.println("Non-Repeting -> " +java8countingofnonrep);

        //Normal Code
        Map<String,Integer> checkingCount = new LinkedHashMap<>();
        String[] strname = name.split("");
        for(String st : strname){

            if(checkingCount.containsKey(st)){
                checkingCount.put(st,checkingCount.getOrDefault(st,0) + 1);
            } else {
                checkingCount.put(st,1);
            }
        }
        String normalCheckCount = "";
        for(Map.Entry<String,Integer> ab : checkingCount.entrySet()){
            if(ab.getValue() == 1){
                normalCheckCount += ab.getKey();
            }
        }

        System.out.println("normalCheckCount -> " + normalCheckCount);




    }

    private static void removedublicatecount() {

        List<Integer> list = Arrays.asList(3,2,5,4,5);
        int[] num = {3,2,5,4,5};

        List<Integer> rmvList = list.stream().distinct().toList();
        System.out.println("Remove List " + rmvList);

        List<Integer> intduplist = Arrays.stream(num).distinct().mapToObj(nn -> Integer.valueOf(nn)).toList();
        System.out.println("IntDupList -> " + intduplist);

    }

    private static void findthecharacteroccaranceinstring() {

        String str = "nishith";

      Map<String,Long> countingofChar =  Arrays.stream(str.split("")).collect(Collectors.groupingBy(
                i-> i, Collectors.counting()
        ));

        System.out.println("Counting of Char " + countingofChar);


    }

    private static void convertedtocommaseparatedString() {

        List<String> list = Arrays.asList("avdhut","doiphode");
        String commaseparated = list.stream().collect(Collectors.joining(","));
        System.out.println("Comma Separated String " + commaseparated);

        String[] abcd = {"avdhut","doiphode"};
        StringBuffer joining = new StringBuffer();
        for(String ss : abcd){
            joining.append(ss);
        }

        System.out.println(joining);





    }

    private static void evennumberfromUsingStream() {

        List<Integer> list = Arrays.asList(1,5,7,8,9,10,15,2);
        String[] name = {"1","5","7","8","9","10","15","2"};
        int[] aa = {1,5,7,8,9,10,15,2};



        List<Integer> evenlist = list.stream().filter(n -> n % 2 == 0).toList();
        System.out.println("EvenList => " + evenlist);

        List<String> stringEvenList = Arrays.stream(name).
                filter(str -> Integer.valueOf(str) % 2 == 0).map(ss -> String.valueOf(ss)).toList();
        System.out.println("Stirng Even List " +stringEvenList);

        List<Integer> intEvenList = Arrays.stream(aa).filter(np -> np % 2 == 0).mapToObj(num -> Integer.valueOf(num)).collect(Collectors.toList());
        System.out.println("Int Even List " + intEvenList);
        
    }

    private static void printwith1injava() {

        String[] wordArray = {"ANish","BPPP","ARRR"};

        List<String> wordWithA =
                Arrays.stream(wordArray).filter(ss -> ss.startsWith("A")).toList();

        System.out.println(wordWithA);

    }

}
