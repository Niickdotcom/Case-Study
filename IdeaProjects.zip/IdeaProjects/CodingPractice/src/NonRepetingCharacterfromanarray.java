import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class NonRepetingCharacterfromanarray {


    public static void main(String[] args) {
        String[] abcd  = {"array", "peacock", "Grapes"};

        Map<Character,Long> abcds = Arrays.stream(abcd).flatMapToInt(String::chars).mapToObj(
                c -> Character.toLowerCase((char) c)
        ).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(abcds);


        List<Integer> myList = Arrays.asList(13,31,1333,34510,167,113,51,15,61);

        List<Integer> Starts_with_one = myList.stream().filter(str -> String.valueOf(str).startsWith("1")).toList();
        System.out.println(Starts_with_one);




    }
}
