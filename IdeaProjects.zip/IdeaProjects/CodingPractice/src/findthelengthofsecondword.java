import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class findthelengthofsecondword {

    public static void main(String[] args) {
        String words = "Helloooooo my name is nishith";

       // Stream.of(words.split(" ")).map(ss -> ss.charAt(2)).peek(aa -> System.out.print(aa)).map(ss -> ss.toString().length()).forEach(ss -> System.out.println(ss));


        String findthirdelementlength = String.valueOf(Stream.of(words.split(" ")).skip(1)
                .peek(ss -> System.out.println(ss)).map(String::length).findFirst());
        System.out.println(findthirdelementlength);


        String findmaxlenght = Arrays.stream(words.split(" "))
                .max(Comparator.comparing(String::length)).get();

        System.out.println("find the max lenght from String " + findmaxlenght);


        String findminimum = Arrays.stream(words.split(" "))
                .min(Comparator.comparing(String::length)).get();

        System.out.println("find the max lenght from String " + findminimum);
        
        
        practiceDay1(words);
    }

    private static void practiceDay1(String words) {

//        findthirdelementlength
        String thirdlength = String.valueOf(Arrays.stream(words.split(" ")).skip(2).map(s -> s.length()).findFirst());
        System.out.println("Third Element --> " +thirdlength);
//        findmaxlenght

        String maxstring = Arrays.stream(words.split(" ")).max(Comparator.comparing(ss -> ss.length())).get();
        System.out.println("MaxStringElement -> " + maxstring);

//        findminlenght
        String minstring = Arrays.stream(words.split(" ")).min(Comparator.comparing(ss -> ss.length())).get();
        System.out.println("MinString " + minstring);
    }
}
