public class Employee {

    private  int Id;
    private  String name;
    private  String gender;
    private  Long age;

    private  Double Salary;
    private  Integer rating;


    public Double getSalary() {
        return Salary;
    }

    public void setSalary(Double salary) {
        Salary = salary;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Long getAge() {
        return age;
    }

    public void setAge(Long age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "Id=" + Id +
                ", name='" + name + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", Salary=" + Salary +
                ", rating=" + rating +
                '}';
    }


//    public Employee(int id, String name, String gender, Long age, Double salary, Integer rating) {
//        Id = id;
//        this.name = name;
//        this.gender = gender;
//        this.age = age;
//        Salary = salary;
//        this.rating = rating;
//    }



}
