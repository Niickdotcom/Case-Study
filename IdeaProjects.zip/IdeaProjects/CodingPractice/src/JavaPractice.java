import java.sql.SQLOutput;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class JavaPractice {

    public static void main(String[] args) {
        printwith1injava();
        evennumberfromUsingStream();
        convertedtocommaseparatedString();
        findthecharacteroccaranceinstring();
        removedublicatecount();
        findthefirstnonrepertingcharacter();
        findmaxlenghtusingStreamAPI();
        sorttheelementinascanddscusingstream();
        pallindromeofanumber();
        testApplication();

    }

    private static void testApplication() {
        String a = "hello";
        String b = "hello";

        String n = new String("hello");
        String p = new String("hello");

        System.out.println("PPPRINT " + n == p);


    }

    private static void pallindromeofanumber() {

        int aa = 151;
        int ii = aa;
        //using normal java

        int reverse = 0;

        while (ii != 0){
            int digi = ii % 10;
            reverse = reverse * 10 + digi;
            ii /= 10;
        }

        System.out.println("reverse  " + reverse);

    }

    private static void sorttheelementinascanddscusingstream() {


//        Write a programme to sort in ascending and descending order by length of the given array of strings.
        String[] arr = {"Green", "White", "Black", "Pink", "Orange", "Blue", "Champagne", "Indigo", "Ivory"};


      List<String> asscedingorder = Arrays.stream(arr).sorted(Comparator.comparingInt(String::length))
                        .toList();
      System.out.println("checking with asc  " + asscedingorder);

      List<String> decendingorder = Arrays.stream(arr).sorted(Comparator.comparingInt(String::length).reversed())
              .toList();
        System.out.println("checking with dsc " + decendingorder);


    }

    private static void findmaxlenghtusingStreamAPI() {

//        find max element using strem
        System.out.println(" ");
        List<Integer> list = Arrays.asList(10,20,500,50,59,80,70,100,400,300);
        Optional<Integer> maxelement = list.stream().max((a,b) -> Integer.compare(a,b)).stream().findFirst();
        System.out.println("Max Element  = " + maxelement);

        //using normal java
        int maxielement = 0;
        int minimumelemt = 0;
        for(int i : list){
            if(maxielement<i){
                minimumelemt = maxielement;
                maxielement = i;
            } else if(minimumelemt < i){
                minimumelemt = i;
            }
        }

        System.out.println("Maximum element " + maxielement);



    }

    private static void findthefirstnonrepertingcharacter() {

//        find first non repeating charcter form string
        System.out.println(" ");
        String name = "Nishith";

        String nonrepeting = name.chars().mapToObj(c -> (char) c).collect(
                Collectors.groupingBy(i -> i,LinkedHashMap::new, Collectors.counting())
        ).entrySet().stream().filter(ss -> ss.getValue() == 1).map(aa -> String.valueOf(aa.getKey())).collect(Collectors.joining());

        System.out.println("First Non repeting character = " + nonrepeting);


        String usingnormalflow = "";
        char[] tochararryb =  name.toCharArray();
        HashMap<Character,Integer> cout = new LinkedHashMap<>();
        for(char cc : tochararryb){
            if(cout.containsKey(cc)){
                cout.put(cc, cout.getOrDefault(cc,1) + 1);
            } else {
                cout.put(cc, 1);
            }
        }

        System.out.println( "Priting an array  " + (cout));

        for(Map.Entry<Character,Integer> ccc : cout.entrySet()){
            if(ccc.getValue() == 1){
                usingnormalflow += ccc.getKey();
            }
        }

        System.out.println("Non-repeting character using normal java " + usingnormalflow);

    }

    private static <Set> void removedublicatecount() {
//        remove duplicate from list
        System.out.println(" ");
        List<Integer> list = Arrays.asList(3,2,5,4,5);

        List<Integer> dublicatecount = list.stream().distinct().toList();
        System.out.println("dublicate using inbuild function" + dublicatecount);

        HashSet<Integer> dublicateset = new HashSet<Integer>();
        List<Integer> usingsetFunctionality = dublicatecount.stream().sorted().filter(
                ss -> dublicateset.add(ss)).collect(Collectors.toList());
        System.out.println("Using setInterface " + usingsetFunctionality);


    }

    private static void findthecharacteroccaranceinstring() {

        //find count the charector occurance in string
        System.out.println(" ");

        String str = "nishith";
        Map<Character,Long> characterocc = str.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(i -> i,Collectors.counting()));
        System.out.println("Character occ = " + characterocc);


    }

    private static void convertedtocommaseparatedString() {

        //converted List<String> to commasapreted string
        System.out.println(" ");
        List<String> list = Arrays.asList("avdhut","doiphode");
        String commaseparated = list.stream().collect(Collectors.joining(","));
        System.out.println("Comma Separated String " + commaseparated);

        String[] abcd = {"avdhut","doiphode"};
        String comastringarray = "";

        for(String op : abcd){
            comastringarray += op;
        }

        System.out.println("comma separated  " + commaseparated);


    }

    private static void evennumberfromUsingStream() {

        System.out.println(" ");
        // find even number from a list using Stream
        List<Integer> list = Arrays.asList(1,5,7,8,9,10,15,2);
        List<Integer> evenlistassending = list.stream().sorted().filter(ss -> ss % 2 == 0).toList();
        System.out.println("Assending evenlist = " + evenlistassending);

        List<Integer> oddlistdescending = list.stream().sorted(Collections.reverseOrder()).filter(ss -> ss % 2 != 0).toList();
        System.out.println("Decending odd List  = " + oddlistdescending);

        int[] numbers = {1,5,7,8,9,10,15,2};
        List<Integer> evenlist = Arrays.stream(numbers).boxed().sorted().filter(ss -> ss % 2 ==0).toList();
        System.out.println("int[] evenlist = " + evenlist);
        System.out.println(" ");

    }

    private static void printwith1injava() {

        //only print with name start with 1
        List<Integer> list = Arrays.asList(123,345, 1235);
        List<Integer> startwitone = list.stream().filter(ss -> String.valueOf(ss).startsWith("1")).toList();
        System.out.println("List Start with one " +  startwitone);

        int[] list2 = {123,345,12345};
        List<Integer> star = Arrays.stream(list2).filter(aa -> String.valueOf(aa).startsWith("1")).boxed().toList();
        System.out.println("List of integer " + star);


        String[] aaa = {"1ne,2ow,3hree"};
        System.out.println("AAAA");
        System.out.println(Arrays.stream(aaa).filter(s -> s.startsWith("1") ||s.startsWith("2") || s.startsWith("2")).toList());


       List<String> opp =  Arrays.stream(aaa).filter(ss -> Character.isDigit(ss.charAt(0))).map(
                dd -> String.valueOf(dd)).toList();
        System.out.println(opp);

        String pallin =  "mom";

        Boolean pall =
                IntStream.range(0, pallin.length()/2).allMatch(
                        i -> pallin.charAt(i) == pallin.charAt(pallin.length()-1-i)
                );

        String drome = "mom";

        IntStream.range(0, drome.length()/2).allMatch(
                i -> drome.charAt(i) == drome.charAt(drome.length()-i-1)
        );

        String wr = "TTyyEEmmSMsssEE";

        String upersplit =
                wr.chars().mapToObj(c -> (char) c).filter(
                        Character::isLowerCase
                ).map(s -> String.valueOf(s)).collect(Collectors.joining());
        System.out.println( "LOWE CASE -> " + upersplit);







    }


}
