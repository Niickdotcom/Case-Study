import java.util.Arrays;

@FunctionalInterface
interface MyFunctionalInterface {
    void doSomething();
}

@FunctionalInterface
interface MyFunctionalInterface1 {
    String doSomething1();
}

public class Funtionalinterfaceexample {

    public static void main(String[] args) {
        MyFunctionalInterface myFunc = () -> System.out.println("Doing something!");
        myFunc.doSomething();

        MyFunctionalInterface1 myfun1 = () -> "Do Something";
        System.out.println(myfun1.doSomething1());
    }
}
