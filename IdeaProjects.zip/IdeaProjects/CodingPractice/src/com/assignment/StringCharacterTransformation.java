package com.assignment;

public class StringCharacterTransformation {


    public static void main(String[] args) {

        System.out.println("**-- Character Transformation Task -- **");
      String finalMessgae = characterTransformationTask();
      System.out.println(finalMessgae);
        System.out.println("**-- Character Transformation Task -- **");



    }

    private static String characterTransformationTask() {


//        Scanner sc = new Scanner(System.in);
//        String iputString = sc.nextLine();

        String ip = "ABCDE";
        String encodedMessage = "";

        if (ip.isEmpty()) {
            encodedMessage = "String is empty";
        } else if (ip.length() <= 4) {
            encodedMessage = "The string "+ip+" has minimum length";
        } else if (checlspace(ip)) {
            System.out.println("inside");
            encodedMessage = "The string "+" " +ip+ " " + " should not contain space ";
        } else {
            if (encodedMessage.isEmpty()) {
                    encodedMessage = encodeMessage(ip);
            }
        }
        return  encodedMessage;
    }

    private static String encodeMessage(String ip) {
        String returnStringEncoded = "";

        int lengString = ip.length();
        StringBuilder strEncoded = new StringBuilder();

        for(char ec : ip.toCharArray()){
            int ascii = (int) ec;
            System.out.println("LengthOfString " + lengString + " Character ->   " + ec + "ASCII value -> " + ascii);
            char encodeChar = (char) (ec - lengString);
            char asciichar = encodeChar;
            System.out.println("acciii " + asciichar);
            strEncoded.append(encodeChar);

        }
        returnStringEncoded = strEncoded.toString();

        return returnStringEncoded;
    }

    private static boolean checlspace(String ip) {
        Boolean checkspace  = ip.contains(" ");
         return  checkspace;
    }
}