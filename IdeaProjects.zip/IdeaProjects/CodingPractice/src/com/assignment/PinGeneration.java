package com.assignment;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PinGeneration {

    public static void main(String[] args) {

            BolockedQuestion();
            PingenerationCode();


    }

    private static void PingenerationCode() {

        String str = "ABZ12345";
        Integer age = 2;

        if(str.length() > 8){
            System.out.println("String lenght " + str.length() + " invlaide lenght membershipID");
        }

        int count =5;
        int digitCoumt = 0;
        for(int i = 0;i<=str.length() -1;i++){
            char ss = str.charAt(i);
            if(i <= 2){
                if(!Character.isLetter(ss)) {
                    System.out.println("First 3 leter should be Alphabet and yours is " + ss);
                }
            } else if(i > 2) {
                String digione = String.valueOf(str.charAt(i));
                if(i == 3 && digione.equals("0")){
                    System.out.println("0 is an invalid digit");
                    break;
                } else {
                    if(Character.isDigit(ss)){
                        digitCoumt++;
                    }
                }
            }

        }
        if(digitCoumt > 0 && count != digitCoumt){
            System.out.println(count + " " + digitCoumt +"is an invalid format");
        }

       Boolean postionStarting  = str.substring(4,4).equals("0");
        if(postionStarting){
            System.out.println(str.substring(4,4) + " is Invlaid");
        }

        if(!str.isEmpty()){
            String pinGeneration  =
                    str.chars().mapToObj(c -> (char) c)
                            .filter(dd -> Character.isDigit(dd) &&
                                    dd % 2 == 0).map(sa -> String.valueOf(sa)).collect(Collectors.joining());

            System.out.println("Ping generation " + pinGeneration);
        }










    }

    private static void BolockedQuestion() {
        /*
        * The library management system is launching a new online portal for book reservations. To ensure security and accuracy, users need to authenticate using a PIN generated based on their membership ID. Develop a Java application to automate the PIN generation process.
Note
1. Start by verifying the length of the membership ID. It should be exactly 8 characters long; otherwise, print "<length of membership ID> is an invalid length" and terminate the application.
2. The membership ID should consist of 3 alphabets followed by 5 digits. If this format is not followed, print "<membership ID> is an invalid format" and terminate the program.
3. The first digit of the numeric part of the membership ID (following the alphabets) should not be '0'. If it is '0', print "<first digit> is an invalid digit" and terminate the program.
4. The last digit of the numeric part of the membership ID should correspond to the age category of the member: 1 for ages 10-20, 2 for ages 21-30, and so on up to 9 for ages 80-90. If it doesn't match any category, print "<age category> is an invalid category" and terminate the program.
Logic of PIN Generation:
- The PIN will be the concatenation of the even-positioned digits (0-indexed) in the numeric part of the membership ID.
Example: Membership ID - ABC12345, Age Category - 2
Generated PIN: 24
Sample Input / Output:
Sample Input 1:
Enter the membership ID
ABC12345
Sample Output 1
PIN: 24
Sample Input 2:
Enter the membership ID
ABCD123
Sample Output 2:
7 is an invalid length
Sample Input 3:
Enter the membership ID
ABC01234
Sample Output 3:
0 is an invalid digit
Sample Input 4:
Enter the membership ID
ABZ12345
Sample Output 4:
ABZ12345 is an invalid format
Sample Input 5:
Enter the membership ID
ABC12356
Sample Output 5:
6 is an invalid category
*/
    }
}
