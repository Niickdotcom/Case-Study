package com.assignment;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.stream.Collectors;

public class studentReverstWords {

    public static void main(String[] args) {


        String words = "You are the apple of my eye";


        if(words.length() < 2){
            System.out.println("Invalid sentence length");
        } else if(words.matches("^ [A-Za-z0-9 ]+$")){
            System.out.println(words + " is an invalid sentence");
        }
        else {

            String[] sss = words.split(" ");
            StringBuilder revese = new StringBuilder();


            for (String ss : sss) {

                int left = "aeiouAEIOU".indexOf(ss.charAt(0));
                int right = "aeiouAEIOU".indexOf(ss.charAt(ss.length() - 1));

                if (left == 0 && right == 1) {
                    revese.append(new StringBuilder(ss).reverse());
                } else {
                    revese.append(ss);
                }
                revese.append(" ");
            }

            System.out.println(revese);

        }


    }

    private static boolean startWithVouwe(String str) {

        String vowe = "aeiouAEIOU";
        return  vowe.indexOf(str.charAt(0)) != -1 && vowe.indexOf(str.charAt(str.length()-1)) != -1;
    }
}
