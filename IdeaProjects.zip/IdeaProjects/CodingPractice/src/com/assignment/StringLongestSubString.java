package com.assignment;

public class StringLongestSubString {
    public static void main(String[] args) {

        checktheSubString();

    }

    private static void checktheSubString() {

        String s1 = "Hello World";
        String s2 = "Yellow Cold";

        if(checkletterorcharcorspace(s1,s2)){
            System.out.println("Invalid Input");
        } else {
            String[] a1 = s1.split(" ");
            String[] a2 = s2.split(" ");


            if(a1[1].isEmpty()) {
                System.out.println("No SubString");
            }
            if(a2[1].isEmpty()){
                System.out.println("No SubString");
            }
            if(!a1[1].isEmpty() && !a2[1].isEmpty()){

                System.out.println(checkLength(a1[1],a2[1]));
            }
        }
    }

    private static String checkLength(String s1, String s2) {
        String checkString = "";
        int first = s1.length();
        int second = s2.length();

        if(first > second){
            checkString = s1.toUpperCase() + " " + s1.toLowerCase();
        } else if (second > first){
            checkString = s2.toUpperCase() + " " + s2.toLowerCase();
        } else {
            checkString = "Both are Equals";
        }

        return  checkString;
    }

    private static boolean checkletterorcharcorspace(String s1, String s2) {
        Boolean commonString = false;

        if(!s1.matches("^[A-Za-z0-9 ]+$") || !s2.matches("^[A-Za-z0-9 ]+$")){
            System.out.println("inside");
            commonString = true;
        }
        return  commonString;

    }
}
