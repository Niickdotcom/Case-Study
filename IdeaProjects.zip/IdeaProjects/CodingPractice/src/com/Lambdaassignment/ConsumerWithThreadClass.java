package com.Lambdaassignment;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerWithThreadClass {

    public static void main(String[] args) {

        List<Integer> numbers = Arrays.asList(10, 20, 30, 40, 50);

        Consumer<Integer> numbersss =
                num -> System.out.println("Pringting num => " + num);

        Thread th1 =  new Thread(() -> {
            numbers.forEach(numbersss);
        });

        th1.start();

    }
}
