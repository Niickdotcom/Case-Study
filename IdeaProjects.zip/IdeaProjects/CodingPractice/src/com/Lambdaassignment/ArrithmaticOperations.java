package com.Lambdaassignment;

@FunctionalInterface
interface  ArithmeticOperation{
    double operate(int a, int b);
}

public class ArrithmaticOperations {
    public static void main(String[] args) {

        ArithmeticOperation addition = (a,b) -> a + b;
        System.out.println(" Addition " +addition.operate(2,4));


        ArithmeticOperation subration = (a,b) -> a - b;
        System.out.println(" Subraction " +subration.operate(2,4));


        ArithmeticOperation mulitplication = (a,b) -> a * b;
        System.out.println(" Multiplication " + mulitplication.operate(2,4));

        ArithmeticOperation division = (a,b) -> a / b;
        System.out.println(" Division " + division.operate(2,4));


    }
}
