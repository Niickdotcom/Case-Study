package com.Lambdaassignment;

import java.util.Arrays;
import java.util.List;
import java.util.function.UnaryOperator;

public class StringUnrinaryOperator {

    public static void main(String[] args) {

        List<String> words = Arrays.asList("Java", "Stream", "Lambda", "Expression");
        UnaryOperator<String>
                op = str -> str.toUpperCase();


        words.replaceAll(op);

        System.out.println("words TO Upper -> " + words);


    }
}
