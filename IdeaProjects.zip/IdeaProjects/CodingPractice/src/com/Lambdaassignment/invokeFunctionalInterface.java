package com.Lambdaassignment;

import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class invokeFunctionalInterface {


    public static void main(String[] args) {


        ConsumetMethod();
        SupplierMethod();
        PredicateMethod();
        functionInterFace();


    }

    private static void PredicateMethod() {

        Predicate<String> str = i -> i.length() > 1;
        System.out.println(str.test("HEllo THis is PREDICATE"));

    }

    private static void functionInterFace() {

        Function<String,String> toUpp = str -> str.toUpperCase();
        System.out.println(toUpp.apply("hell i am functionalInterface"));
    }

    private static void SupplierMethod() {

        Supplier<Integer> cal = () -> (int) (Math.random() * 100) * 10;
        System.out.println(cal.get());


    }

    private static void ConsumetMethod() {

        Consumer<String> word =
                str -> System.out.println(str);

        word.accept("Hello I am Consumer");



    }
}
