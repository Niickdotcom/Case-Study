package com.Lambdaassignment;

import java.util.Arrays;
import java.util.List;

public class CollectionofStringFirstchar {

    public static void main(String[] args) {


        List<String> words = Arrays.asList("Java", "Stream", "Lambda", "Expression");


        List<Character> firstCharword = words.stream().map(stratf -> stratf.charAt(0)).toList();

        System.out.println("First Character Priniting -> " + firstCharword);



    }
}
