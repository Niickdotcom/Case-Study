package com.Lambdaassignment;


import java.util.Arrays;
import java.util.List;

enum Status {
    ACCEPTED, COMPLETED, CANCELLED, PENDING
}


class  Order{
    int id;
    double price;
    Status status;

    public Status getStatus() {
        return status;
    }

    public double getPrice() {
        return price;
    }

    public int getId() {
        return id;
    }

    public Order(int id, double price, Status status) {
        this.id = id;
        this.price = price;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", price=" + price +
                ", status=" + status +
                '}';
    }
}

public class OrderStreamPractice {


    public static void main(String[] args) {
        List<Order> orders = Arrays.asList(
                new Order(1, 12000, Status.ACCEPTED),
                new Order(2, 8000, Status.COMPLETED),
                new Order(3, 15000, Status.CANCELLED),
                new Order(4, 20000, Status.COMPLETED),
                new Order(5, 5000, Status.ACCEPTED),
                new Order(6, 11000, Status.PENDING)
        );





        OrderBasedOnCriteria(orders);

    }

    private static void OrderBasedOnCriteria(List<Order> orders) {

//        Write an application using lambda expressions to print Orders having 2
//        criteria implemented:
//        1) order price more than 10000
//        2) order status is ACCEPTED or COMPLETED

      List<Order> getOrdersprmr10000andstAC =   orders.stream().filter(ordpriceandstatus ->
                ordpriceandstatus.getPrice() > 10000 &&
                        (ordpriceandstatus.getStatus().equals(Status.ACCEPTED) ||
                                ordpriceandstatus.getStatus().equals(Status.COMPLETED)))
                .toList();

        System.out.println("Orer Price greated then 10000 and status = A or C " +
                getOrdersprmr10000andstAC);





    }


}
