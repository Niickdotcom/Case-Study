package com.Lambdaassignment;

import java.util.*;

public class maptostring {
    public static void main(String[] args) {


        Map<String, String> map = new LinkedHashMap<>();
        map.put("name", "Alice");
        map.put("city", "Mumbai");
        map.put("language", "Java");

        StringBuilder listString = new StringBuilder();

        for(Map.Entry<String,String> wrd : map.entrySet()){
            listString.append(wrd.getKey()).append(" ").append(wrd.getValue()).append(" ");
        }


        System.out.println(listString);



    }
}
