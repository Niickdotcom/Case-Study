package com.Lambdaassignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class CollectionRemoveIf {

    public static void main(String[] args) {



        List<String> removeOddLength =  new ArrayList<>(Arrays.asList("apple", "banana", "kiwi", "grape", "melon", "fig", "plum"));
//
        removeOddLength.removeIf(removeOddLengths -> removeOddLengths.length()  % 2 != 0);
//
        System.out.println("Removide the ODD LENGTH DATA  -> " + removeOddLength);





    }
}
