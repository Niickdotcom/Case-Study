package com.assignment2;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PracticeTable {


    public static void main(String[] args) {



        List<Fruit> fruits = Arrays.asList(
                new Fruit("Apple", 95, 50, "Red"),
                new Fruit("Banana", 105, 20, "Yellow"),
                new Fruit("Cherry", 85, 60, "Red"),
                new Fruit("Orange", 62, 30, "Orange"),
                new Fruit("Grapes", 67, 40, "Green"),
                new Fruit("Blueberry", 57, 70, "Blue")
        );




        List<News> newsList = Arrays.asList(
                new News(101, "Alice", "Bob", "Great budget discussion"),
                new News(102, "Charlie", "Dave", "Budget is tight this year"),
                new News(101, "Alice", "Eve", "Interesting perspective"),
                new News(103, "Frank", "Bob", "Loved the budget insights"),
                new News(102, "Charlie", "Eve", "Not convinced by the budget"),
                new News(104, "Grace", "Heidi", "Nice article")
        );

        Trader t1 = new Trader("Alice", "Delhi");
        Trader t2 = new Trader("Bob", "Pune");
        Trader t3 = new Trader("Charlie", "Indore");
        Trader t4 = new Trader("Dave", "Delhi");
        Trader t5 = new Trader("Eve", "Pune");


        List<Transaction> transactions = Arrays.asList(
                new Transaction(t1, 2011, 300),
                new Transaction(t2, 2012, 1000),
                new Transaction(t3, 2011, 400),
                new Transaction(t4, 2013, 710),
                new Transaction(t5, 2011, 700),
                new Transaction(t1, 2012, 950)
        );



        fruitNameofLowCalories(fruits);
        displayColorWiseFruitName(fruits);
        displayRedColorFruitSortedasperPrice(fruits);


        //News Clas
        findnewsIdbasedoncomments(newsList);
        findhowmanytimeswordBudgetisArrivedinComments(newsList);
        findoutwhichuserHasPostMaximumComment(newsList);
        findcommentByUserandCounts(newsList);



        //Trade Class
        findTransactionasyearandsortthembyvalue(transactions);
        findUnquesCitieswheretradework(transactions);
        findallTradesfrmPuneandSortByName(transactions);
        returnallTradersNameSorted(transactions);
        checkifTraderarebasedonIndore(transactions);
        printalltranvaluefromcitydelhi(transactions);
        highestValueofAllTransaction(transactions);
        minimumValueofAllTransaction(transactions);


    }

    private static void minimumValueofAllTransaction(List<Transaction> transactions) {
//        Find the transaction with the smallest value


        Transaction mimmumValue =
                transactions.stream().sorted(Comparator.comparingInt(Transaction::getValue)).findFirst().get();

        System.out.println("Transaction With Minimum Values -> " + mimmumValue);
    }





    private static void highestValueofAllTransaction(List<Transaction> transactions) {
//        What’s the highest value of all the transactions?
      Transaction maxTransactionm =   transactions.stream().max(Comparator.comparingInt(Transaction::getValue)).get();
        System.out.println("Maximum Transaction Data " + maxTransactionm);

    }

    private static void printalltranvaluefromcitydelhi(List<Transaction> transactions) {

      List<Integer> valueofDelhiTrade = transactions.stream().filter(trnc -> trnc.getTrader().getCity().equalsIgnoreCase("delhi"))
                .map(Transaction::getValue).toList();

        System.out.println("Trade Values from Delhi -> " + valueofDelhiTrade);

    }

    private static void checkifTraderarebasedonIndore(List<Transaction> transactions) {

//        Are any traders based in Indore?

        List<Transaction> tranderbasedonIndore =
                transactions.stream().filter(tracity -> tracity.getTrader().getCity().equalsIgnoreCase("Indore"))
                        .toList();

        System.out.println("Traders based on city Indore -> " + tranderbasedonIndore);
    }

    private static void returnallTradersNameSorted(List<Transaction> transactions) {

//        Return a string of all traders’ names sorted alphabetically.

        List<String> nameofTraders =
                transactions.stream().sorted(Comparator.comparing(
                        trnname -> trnname.getTrader().getName()
                )).map(tradername -> tradername.getTrader().getName()).toList();

        System.out.println("Name Of Trader sorted alphabetically order " +  nameofTraders);


    }

    private static void findallTradesfrmPuneandSortByName(List<Transaction> transactions) {

//        Find all traders from Pune and sort them by name

      List<Transaction> traderfrompune =  transactions.stream().filter(trn -> trn.getTrader().getCity().equalsIgnoreCase("pune"))
                .sorted(Comparator.comparing(trnname -> trnname.getTrader().getName()))
                .toList();

        System.out.println("Traders from Pune and sorted name -> " + traderfrompune);


    }

    private static void findUnquesCitieswheretradework(List<Transaction> transactions) {

        String uniqueCities =
                transactions.stream().map(trci ->
                        trci.getTrader().getCity()).distinct()
                        .collect(Collectors.joining(","));


        System.out.println("unique City -> " + uniqueCities);
    }

    private static void findTransactionasyearandsortthembyvalue(List<Transaction> transactions) {

//        Find all transactions in the year 2011 and sort them by value (small to
//                high).


        System.out.println(transactions);

       List<Transaction> sortwithyear =  transactions.stream().filter(years -> years.getYear() == 2011)
                .sorted(Comparator.comparingInt(Transaction::getValue))
                .toList();

        System.out.println("Transction year = 2011 and sort value " + sortwithyear);




    }

    private static void findcommentByUserandCounts(List<News> newsList) {
//        Display commentByUser wise number of comments.

    Map<String,Long> countMapCommentedUser =     newsList.stream().collect(Collectors.groupingBy(
                i -> i.getCommentByUser(),Collectors.counting()
        ));

        System.out.println("Commented User by Count -> " + countMapCommentedUser);
    }



    private static void findoutwhichuserHasPostMaximumComment(List<News> newsList) {

//        Find out which user has posted maximum comments

      String neameofUser =   newsList.stream().collect(Collectors.groupingBy(
              i -> i.getCommentByUser(), LinkedHashMap::new,Collectors.counting()
      )).entrySet().stream().filter(
              cmtuset -> cmtuset.getValue() > 1
      ).map(cmtuser -> cmtuser.getKey())
              .collect(Collectors.joining(","));

        System.out.println("Maximum Comment User name -> " + neameofUser);




    }

    private static void findhowmanytimeswordBudgetisArrivedinComments(List<News> newsList) {
//        Find out how many times the word 'budget' arrived in user comments all
//        news.

       Long totalCommentCount = newsList.stream().filter(commentCount ->
                commentCount.getComment().toLowerCase().contains("budget"))
                .count();

        System.out.println("Total Comment preset Budget -> " + totalCommentCount);

    }

    private static void findnewsIdbasedoncomments(List<News> newsList) {
    // Find out the newsId which has received maximum comments


        System.out.println(newsList);

//        News{newsId=101, postedByUser='Alice', commentByUser='Bob', comment='Great budget discussion'},
//        News{newsId=102, postedByUser='Charlie', commentByUser='Dave', comment='Budget is tight this year'},
//        News{newsId=101, postedByUser='Alice', commentByUser='Eve', comment='Interesting perspective'},
//        News{newsId=103, postedByUser='Frank', commentByUser='Bob', comment='Loved the budget insights'},
//        News{newsId=102, postedByUser='Charlie', commentByUser='Eve', comment='Not convinced by the budget'},
//        News{newsId=104, postedByUser='Grace', commentByUser='Heidi', comment='Nice article'}


       Integer newsIdbasedonComment =  newsList.stream().max(Comparator.comparing(News::getComment))
                .map(News::getNewsId).get();

        System.out.println("News Id which has maximum comment -> " + newsIdbasedonComment);

        newsList.stream()
                .collect(Collectors.groupingBy(News::getNewsId, Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .ifPresent(entry -> System.out.println("Max comments on newsId: " + entry.getKey()));


    }

    private static void displayRedColorFruitSortedasperPrice(List<Fruit> fruits) {


//        Display only RED color fruits sorted as per their price in ascending order.

       List<String> fruitNameAccordingtoColor =  fruits.stream().filter(frucol -> frucol.getColor().equalsIgnoreCase("red"))
                .sorted(Comparator.comparingInt(Fruit::getPrice))
                .map(Fruit::getName).toList();


        System.out.println("Fruits Names according to coloru and Price -> " + fruitNameAccordingtoColor);




    }

    private static void displayColorWiseFruitName(List<Fruit> fruits) {

//        Display color wise list of fruit names.


     fruits.stream().collect(Collectors.groupingBy(
             Fruit::getColor,Collectors.mapping(Fruit::getName, Collectors.toList())
     )).forEach((color,name) -> System.out.println(color +" : "+ name));

// System.out.println("Color wise Display -> " + colorwiseDisplay);

    }

    private static void fruitNameofLowCalories(List<Fruit> fruits) {
        //Display the fruit names of low calories fruits i.e. calories < 100
        // sorted in descending order of calories.


        List<String> listOfFruitName =
                fruits.stream()
                        .filter(cal -> cal.getCalories() < 100)
                        .sorted(Comparator.comparingInt(Fruit::getCalories).reversed())
                        .map(Fruit::getName).toList();

        System.out.println("List of Fruit Name less then 100 Calories " + listOfFruitName);



    }

}
