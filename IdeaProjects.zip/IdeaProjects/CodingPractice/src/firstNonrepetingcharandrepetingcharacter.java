import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class firstNonrepetingcharandrepetingcharacter {

    public static void main(String[] args) {


        String name = "Nishith";
        String nonrepetingChar ="";
        String repetingChar = "";
        Map<Character,Long> counting = name.chars().mapToObj(
                c -> (char) c
        ).collect(Collectors.groupingBy(i -> i, LinkedHashMap::new,Collectors.counting()));

        System.out.println(counting);

        for(Map.Entry<Character,Long> nonrepeting : counting.entrySet()){

            if(nonrepeting.getValue() == 1){
                nonrepetingChar += nonrepeting.getKey();
            }
        }

        for(Map.Entry<Character,Long> nonrepeting : counting.entrySet()){

            if(nonrepeting.getValue() > 1){
                repetingChar += nonrepeting.getKey();
            }
        }

        System.out.println("Non Repeting Character " + nonrepetingChar);
        System.out.println("Repeting Character " + repetingChar);

        practice1();
    }

    private static void practice1() {

        String input = "Rajaram is a good boy";

//        String non_rep

       Map<Character,Long> countingofletter = input.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(i -> i, LinkedHashMap::new,Collectors.counting()));
        System.out.println("Counting " + countingofletter);

        String non_rep =
                countingofletter.entrySet().stream().filter(s -> s.getValue() == 1).map(s -> String.valueOf(s.getKey())).collect(Collectors.joining());

        System.out.println(non_rep);
    }
}
