import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class RemoveSpacesfromString {

    public static void main(String[] args) {
        String sentence = "Hi Hello World";


        String remvoeSpace = sentence.chars().mapToObj(c -> (char) c).filter(Character::isAlphabetic)
                .map(s -> String.valueOf(s)).collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
                .entrySet().stream().filter(c -> c.getValue() == 1).map(e -> e.getKey()).collect(Collectors.joining());

        System.out.println(remvoeSpace);


        practice(sentence);


        String in = "abbcccaa";
        String op = counttheletter(in);
        System.out.println(op);
//		op = a1b2c3
    }

    private static void practice(String sentence) {

        String countspace ="";
    }


    private static String counttheletter(String in) {
        StringBuffer result = new StringBuffer();
//    a b b c c c
//    0 1 2 3 4 5
        int count = 1;
        for(int i=1;i<in.length();i++) {
            if(in.charAt(i) == in.charAt(i - 1)) {
                count++;
            } else {
                result.append(in.charAt(i - 1)).append(count);
                count = 1;
            }

        }

        result.append(in.charAt(in.length() - 1)).append(count);



        return result.toString();
    }
}
