import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class newJavaPractices {

    public static void main(String[] args) {

        printwith1injava();
        evennumberfromUsingStream1();
        convertedtocommaseparatedString1();
        firstNonrepetingcharandrepetingcharacter1();
//        findthecharacteroccaranceinstring();
//        removedublicatecount();
//        findthefirstnonrepertingcharacter();
        findmaxlenghtusingStreamAPI1();
//        sorttheelementinascanddscusingstream();
        pallindromeofanumber1();
        remocvethevowels();
        maximuimStringCount();


    }

    private static void maximuimStringCount() {


        String[] name = {"Nishith","Mehta"};

        String wrdleng =  Arrays.stream(name).max(Comparator.comparing(String::length)).get();
        System.out.println(wrdleng);



    }

    private static void remocvethevowels() {


        String name = "Nishtihmehta";

        String removevolvers = name.chars().mapToObj(ss -> (char) ss).filter(ss -> "aeiou".contains(String.valueOf(ss))).map(
                sss -> String.valueOf(sss)
        ).collect(Collectors.joining());

        System.out.println("Rmovin volves -> " + removevolvers);

    }

    private static void pallindromeofanumber1() {


        int aa = 151;

        int temaa = aa;
        int revse = 0;

        while (temaa > 0){

            int dig = temaa % 10;
            revse = revse * 10 + dig;
            temaa /= 10;
        }

        if(revse ==  aa){
            System.out.println("is pall");
        }


        String aaa = "mom";

       Boolean ispallindrome = IntStream.range(0, aaa.length()/2).allMatch(
               ss -> aaa.charAt(ss) == aaa.charAt(aaa.length() - ss -1)
       );

        System.out.println( " isPallindrome " + ispallindrome);

        Boolean ispalindrom  =  IntStream.range(0, aaa.length()/2).allMatch(
                popo -> aaa.charAt(popo) == aaa.charAt(aaa.length() - popo - 1)
        );
        System.out.println("is plaindrom");


    }

    private static void findmaxlenghtusingStreamAPI1() {

        List<Integer> list = Arrays.asList(10,20,500,50,59,80,70,100,400,300);
        int[] aa = {10,20,500,50,59,80,70,100,400,300};


        //sum of all numnber

        Integer sumofnumber =Arrays.stream(aa).sum();
        System.out.println(sumofnumber);


        Integer sumofevennumber =
                Arrays.stream(aa).filter(ss -> ss % 2 == 0).sum();
        System.out.println( "sum of even " + sumofevennumber);

        //sum + square root and then sume

        Integer sumofevennmber  = Arrays.stream(aa).filter(ss -> ss % 2 == 0).map( qqq -> qqq * qqq).sum();
        System.out.println("sssum of even number "  + sumofevennmber);



        Integer  PPP   = list.stream().max(Comparator.comparingInt(Integer::intValue)).get();
        System.out.println(PPP);


        Integer llll =  Arrays.stream(aa).mapToObj( ss -> Integer.valueOf(ss)).max(
                Comparator.comparingInt(Integer::intValue)
        ).get();


        HashMap<Integer, String> ooo = new HashMap<>();
        ooo.put(1,"name");
        ooo.put(2,"pppp");


       Set<Map.Entry<Integer,String>> setmap =  ooo.entrySet();
       List<Map.Entry<Integer,String>> liss  = new ArrayList<>(setmap);
        System.out.println(liss);


//        List<?> aaa  = Stream.concat(saa,pppaa).toList();

    }

    private static void firstNonrepetingcharandrepetingcharacter1() {

        String name1 = "Nishtih Mehta";

        Optional<Character> op = name1.chars().mapToObj(c -> (char)c ).collect(
                Collectors.groupingBy(dd -> dd,LinkedHashMap::new,Collectors.counting())
        ).entrySet().stream().filter(ss -> ss.getValue() == 1).map(pa -> pa.getKey()).findFirst();

        System.out.println( "aaa " + op);

        Optional<Character> op1 = name1.chars().mapToObj(qq -> (char) qq).collect(
                Collectors.groupingBy(ll -> ll, LinkedHashMap::new,Collectors.counting())
        ).entrySet().stream().filter(ss -> ss.getValue() == 1).map(aaa -> aaa.getKey()).findFirst();
        System.out.println(op1);


        String removeSpaceandString =
                name1.chars().mapToObj(
                                c -> (char) c).map(
                                Character::isLetterOrDigit).
                        collect(Collectors.groupingBy(
                                i -> i, LinkedHashMap::new, Collectors.counting())).entrySet().stream().
                        filter(a1 -> a1.getValue() > 1).
                        map(a2 -> String.valueOf(a2.getKey())).
                        collect(Collectors.joining());


        System.out.println("remove Spoc" +  removeSpaceandString);

        String aa = "aabccddb";
//      op = abc

        Optional<Character> ffff = aa.chars().mapToObj(qq -> (char) qq).collect(
                Collectors.groupingBy(ll -> ll, LinkedHashMap::new,Collectors.counting())
        ).entrySet().stream().filter(ss -> ss.getValue() == 1).map(aaa -> aaa.getKey()).findAny();
        System.out.println( " aaa " + ffff);







    }

    private static void convertedtocommaseparatedString1() {

        //converted List<String> to commasapreted string
        System.out.println(" ");
//        List<String> list = Arrays.asList("Nishith" Mehta");
//        String[] name  = {"Nishith", "Mehta"};

        String name1 = "Nishtih Mehta";

        Map<Character, Long> aa =   name1.chars().mapToObj(s -> (char) s).filter(Character::isAlphabetic).collect(
                Collectors.groupingBy(pq -> pq, Collectors.counting())
        );

      List<Character> ppp =   name1.chars().mapToObj(s -> (char) s).filter(Character::isAlphabetic).collect(
                Collectors.groupingBy(pq -> pq, Collectors.counting())
        ).entrySet().stream().filter(ss -> ss.getValue() > 1).map(ss -> ss.getKey()).toList();

        System.out.println("aa " + ppp);








    }

    private static void evennumberfromUsingStream1() {

        List<Integer> list = Arrays.asList(1,5,7,8,9,10,15,2);
        String[] name = {"1","5","7","8","9","10","15","2"};
        int[] aa = {1,5,7,8,9,10,15,2};


        List<Integer> evenlist = list.stream().filter(s -> s % 2 == 0).toList();
        System.out.println("even List " + evenlist);

        List<String> evemlist = Arrays.stream(name).filter(ss -> Integer.valueOf(ss) % 2 == 0).toList();
        System.out.println(" String evenmlist = " + evemlist);

        List<Integer> usingint = Arrays.stream(aa).filter(ss ->  ss % 2 == 0).mapToObj(
                ss -> Integer.valueOf(ss)
        ).toList();
        System.out.println(usingint);



        List<Integer> list1 = Arrays.asList(1,5,7,8,9,10,15,2);
        String[] name1 = {"1","5","7","8","9","10","15","2"};
        int[] aa1 = {1,5,7,8,9,10,15,2};

        List<Integer> pract1 = list1.stream().filter(ss -> ss % 2 == 0).toList();
        System.out.println(pract1);

        List<String> pract2 = Arrays.stream(name1).filter(ss -> Integer.valueOf(ss) % 2 == 0).toList();
        System.out.println(pract2);

        List<Integer> pract3 = Arrays.stream(aa1).filter(pp -> pp %  2 == 0).mapToObj(ddd -> Integer.valueOf(ddd)).toList();
        System.out.println(pract3);

    }

    private static void printwith1injava() {

        List<Integer> list = Arrays.asList(123, 345, 1235);
        String[] aaa = {"1ne", "2ow", "3hree"};
        int[] inte = {123, 345, 1235};

        List<Integer> startingwith1 = list.stream().filter(s -> String.valueOf(s).startsWith("1")).toList();
        System.out.println("Startwith1" + startingwith1);

        List<String> strwithone =
                Arrays.stream(aaa).filter(ss -> Character.isDigit(ss.charAt(0))).toList();

        System.out.println("strwithone" + strwithone);


        List<String> practstr = Arrays.stream(aaa).filter(ds -> Character.isDigit(ds.charAt(0))).toList();
        System.out.println("Practistr" + practstr);

        List<Integer> practice = Arrays.stream(inte).filter(ss -> String.valueOf(ss).startsWith("3")).boxed().toList();
        System.out.println(practice);


        List<Integer> list1 = Arrays.asList(123,345, 1235);
        String[] aaa1 = {"1ne","2ow","3hree"};
        int[] inte1 = {123,345, 1235};
        
        List<Integer> newlist1 = list1.stream().filter(s -> String.valueOf(s).startsWith("1")).toList();
        
        List<String> neaaa1 = Arrays.stream(aaa1).filter(ss -> Character.isDigit(ss.charAt(0))).toList();

        List<Integer> newinte = Arrays.stream(inte1).filter(s -> String.valueOf(s).startsWith("3")).mapToObj(
                ss -> Integer.valueOf(ss)
        ).collect(Collectors.toList());
        System.out.println(newinte);
 




    }
}
