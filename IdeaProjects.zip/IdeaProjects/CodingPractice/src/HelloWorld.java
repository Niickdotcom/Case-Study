import java.util.Arrays;

public class HelloWorld {
static int i=20;
public static void main(String[] args) {


    HelloWorld.i = HelloWorld.i + 10;

    System.out.println("Hello World " + HelloWorld.i);

    HelloWorld obj1 = new HelloWorld();
    System.out.println("III -> " + i);
    obj1.i = obj1.i + 10;//10+10=20


    System.out.println("Hello World 2 " + HelloWorld.i);
    System.out.println(obj1.i);//20
}
}