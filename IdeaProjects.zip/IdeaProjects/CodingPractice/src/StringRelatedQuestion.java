import java.util.Scanner;

import static java.lang.CharSequence.compare;


public class StringRelatedQuestion {

    public static void main(String[] args) {
        String str1 = new String("Hello World"); //Create String in Heap Memory with new object
        String str2 = new String("Hello World"); //Create String in Heap Memory with new Object

        String str3 = "Hello World"; // This will create the String in String pool constant with one reference
        String str4 = "Hello World"; // This will create the String in String pool constant with same above reference

        int a = 0, b = 0, c = 0;

        //First Scenario
        System.out.println("First Scenario");
        System.out.println("str1  = " + str1 + " str2  = " +  str2 + " both with ==  " + (str1 == str2) );
        System.out.println("str1  = " + str1 + " str2  = " +  str2 + " both with .equals  " + str1.equals(str2));
        System.out.println("----------------");

        //Second Scenario
        System.out.println("Second Scenario");
        System.out.println("str3  = " + str3 + " str4  = " +  str4 + " both with ==  " + (str3 == str4) );
        System.out.println("str3  = " + str3 + " str4  = " +  str4 + " both with .equals  " + str3.equals(str4) );
        System.out.println("----------------");

        //Third Scenario
        System.out.println("Third Scenario");
        System.out.println("str1  = " + str1 + " str3  = " +  str3 + " both with ==  " + (str1 == str3) );
        System.out.println("str1  = " + str1 + " str3  = " +  str3 + " both with .equals  " + str1.equals(str3) );
        System.out.println("----------------");


        //Fourth Scenario
        System.out.println("Fourth Scenario");
        System.out.println("str2  = " + str2 + " str4  = " +  str4 + " both with ==  " + (str2 == str4) );
        System.out.println("str2  = " + str2 + " str4  = " +  str4 + " both with .equals  " + str2.equals(str4) );
        System.out.println("----------------");

        if(str3 == str4){
            a = 1;
        } else {
            a = 2;
        }

        if(str1.equals(str3)){
            b = 1;
        } else{
            b = 2;
        }

        if(str1 == str4){
            c = 1;
        } else{
            c = 2;
        }

        System.out.println("a = " + a + " b = " + b + " c = " + c);


        System.out.println(0.3%3==0.1);
        System.out.println(0.2%2==0.2);


        String name  = "Nishith";
        name.concat("Mehta");
        System.out.println(" it will not change -> " + name);

        String name2 = name.concat("Mehta");
        System.out.println("It will add i guess " + name2);

        compare(name,name2);
        name.compareTo(name2);


//        java 100
//        cpp 65
//        python 50
        Scanner sc=new Scanner(System.in);
        System.out.println("================================");
        for(int i=0;i<3;i++){
            String s1=sc.next();
            int x=sc.nextInt();
            //Complete this line
            String xon;
            String aa = String.valueOf(x);
            System.out.println(" lenght  " + aa.length());
            System.out.println(aa.length() <= 2);
            if(aa.length() <= 2){
                xon = "0"+x;
            } else {
                xon = String.valueOf(x);
            }
            System.out.println(s1+"           "+xon);


            String space = "           ";




        }


    }


}
