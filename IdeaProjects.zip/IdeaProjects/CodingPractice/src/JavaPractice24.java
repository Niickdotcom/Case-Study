import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class JavaPractice24 {

    public static void main(String[] args) {


        printwith1injava24();
        evennumberfromUsingStream24();
        convertedtocommaseparatedString24();
        findthecharacteroccaranceinstring24();
        removedublicatecount24();
        findthefirstnonrepertingcharacter24();
        findmaxlenghtusingStreamAPI24();
        sorttheelementinascanddscusingstream24();
        pallindromeofanumber24();
        remocvethevowels24();
        buySellStockProblem24();
        consverStringtoCamclecase24();
        findMaxLengthofElement24();
        findthetotallenghtofwordinaString24();


    }

    private static void findMaxLengthofElement24() {
        System.out.println(" ");
    }

    private static void consverStringtoCamclecase24() {
        System.out.println(" ");
    }

    private static void buySellStockProblem24() {
        System.out.println(" ");
    }

    private static void remocvethevowels24() {
        System.out.println(" ");
    }

    private static void pallindromeofanumber24() {
        System.out.println(" ");
    }

    private static void sorttheelementinascanddscusingstream24() {
        System.out.println(" ");
    }

    private static void findmaxlenghtusingStreamAPI24() {
        System.out.println(" ");
    }

    private static void findthefirstnonrepertingcharacter24() {
        System.out.println(" ");
    }

    private static void removedublicatecount24() {
        System.out.println(" ");
    }

    private static void findthecharacteroccaranceinstring24() {
        System.out.println(" ");
    }

    private static void convertedtocommaseparatedString24() {
        System.out.println(" ");
    }

    private static void evennumberfromUsingStream24() {
        System.out.println(" ");

        List<Integer> list = Arrays.asList(1,5,7,8,9,10,15,2);
        String[] name = {"1","5","7","8","9","10","15","2"};
        int[] aa = {1,5,7,8,9,10,15,2};

        List<Integer> printingevennumber = list.stream().filter(ss -> ss % 2 == 0).toList();
        System.out.println("Practive 1 " + printingevennumber);

        List<String> printingeveninstring = Arrays.stream(name).filter(s1 -> Integer.valueOf(s1) % 2 == 0).toList();
        System.out.println("Practice 2 " + printingeveninstring);

        List<Integer> prtintgerarray = Arrays.stream(aa).filter(s2 -> s2 % 2 == 0).mapToObj(
                str -> Integer.valueOf(str)
        ).toList();

        System.out.println("Practice 3 " + prtintgerarray);


//        Optional<Integer> TopintgeranditsSquare =
//                Arrays.stream(aa).sorted(Comparator.comparingInt(s1,s2)).filter(sr -> sr % 2 == 0).skip(1).mapToObj(
//                        stt -> Integer.valueOf(stt) * Integer.valueOf(stt)
//                ).findFirst();




    }

    private static void printwith1injava24() {

        List<Integer> list = Arrays.asList(123,345, 1235);
        String[] aaa = {"1ne","2ow","3hree","four"};
        int[] inte = {123,345, 1235};
        System.out.println(" ");

        List<Integer> usinglist = list.stream().filter(ss -> String.valueOf(ss).startsWith("1")).toList();
        System.out.println("Practice 1 -> " +  usinglist);

        List<String> practice2 = Arrays.stream(aaa).filter(wrd -> Character.isDigit(wrd.charAt(0))).toList();
        System.out.println("Practice 2 -> " + practice2);

        List<Integer> practice3 = Arrays.stream(inte).filter(ss -> String.valueOf(ss).startsWith("1")).boxed().toList();
        System.out.println("Practice 3 -> " + practice3);


        
    }

    private static void findthetotallenghtofwordinaString24() {


        System.out.println(" ");

        String[] input = {"nishith","mehta","jobin","thomas","chinmay","bandekar"};
        String findthelargestelemet = "Nishith";


       Map<String,Integer> opp =  Arrays.stream(input).collect(Collectors.toMap(
               wr -> wr, wr -> wr.length()
        ));

        System.out.println("Counting the lenght of a string arrya -> " +  opp);

        //find the highet String from the list

        String highestlenght = Arrays.stream(input).collect(Collectors.toMap(
                wrd -> wrd, wrd -> wrd.length()
        )).entrySet().stream().max(Comparator.comparing(ww -> ww.getValue())).map(www -> www.getKey()).get();

        System.out.println("Highest length of the string array is  -> " + highestlenght);


        String highestvalueusingmax = Arrays.stream(input).max(Comparator.comparingInt(String::length)).get();
        System.out.println("Highest value using max -> " + highestvalueusingmax);










        
        
        
        
    }

}
