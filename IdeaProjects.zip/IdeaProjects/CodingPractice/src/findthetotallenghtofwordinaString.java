import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class findthetotallenghtofwordinaString {

    public static void main(String[] args) {

        String[] input = {"nishith","mehta","jobin","thomas","chinmay","bandekar"};

        Map<String,Integer> result = Arrays.stream(input).collect(
                Collectors.toMap(words -> words, words -> words.length())
        );

        System.out.println(result);

        String largest = result.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(null);
        System.out.println("Largest length -> " + largest );

        int maxlenght = 0;
        String largeword = "";
        for(Map.Entry<String,Integer> forlargest : result.entrySet()){
            if(forlargest.getValue() > maxlenght){
                maxlenght = forlargest.getValue();
                largeword = forlargest.getKey();
            }
        }

        System.out.println("Largest word with for Loop --> " + largeword);


        String findthelargestelemet = "Nishith";

        Map<Character,Long> charresult = findthelargestelemet.chars().mapToObj(
                c -> (char) c).collect(Collectors.groupingBy(i -> i,Collectors.counting()));

        System.out.println(charresult);

    }
}
