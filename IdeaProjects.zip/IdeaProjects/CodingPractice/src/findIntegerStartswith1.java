import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class findIntegerStartswith1 {


    public static void main(String[] args) {
        Integer[] numbers = {11,23,22,14,10,44,55,11,1};
        //find the number starting with 1

        List<Integer> result = Arrays.stream(numbers).filter(
                s -> String.valueOf(s).startsWith("1")
        ).toList();

//        System.out.println(result);
        //Convert it to map also

        Map<Integer,Long> mapresult = Arrays.stream(numbers).filter(
                s -> String.valueOf(s).startsWith("1")
        ).collect(Collectors.groupingBy(i -> i, Collectors.counting()));

        System.out.println(mapresult);

        for(Map.Entry<Integer,Long> countof2 : mapresult.entrySet()){

            if(countof2.getValue() == 2){
                System.out.println(countof2.getKey());
            }
        }


        List<Integer> opp = Arrays.stream(numbers).filter(
                s -> String.valueOf(s).startsWith("1")
        ).toList();

        System.out.println("Converting into list " +opp);

    }
}
