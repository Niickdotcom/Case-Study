import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class convertintocamelcase {

    public static void main(String[] args) {

        String word = "helloworld";
        //convert into camel case
        //Result = helloWorld
//        String camelCase = Arrays.stream(input.split("_"))
//                .map(String::toLowerCase)
//                .map((word, index) -> index == 0
//                        ? word
//                        : Character.toUpperCase(word.charAt(0)) + word.substring(1))
//                .collect(Collectors.joining());

        String camelCase = IntStream.range(0,word.length()).mapToObj(i -> i == 5 ?
                String.valueOf(Character.toUpperCase(word.charAt(i)))
                : String.valueOf(word.charAt(i))).collect(
                        Collectors.joining());

        System.out.println( "Camel Case -> " + camelCase);


        practiceDay1(word);
        

    }





    private static void practiceDay1(String word) {

      IntStream.range(0,word.length()).mapToObj(
                i -> i == 5 ? String.valueOf(Character.toUpperCase(word.charAt(i))) :
                      String.valueOf(word.charAt(i))
      );

        System.out.println("aaaa");

        System.out.println(IntStream.range(0,word.length()).mapToObj(
                i -> i == 5 ? String.valueOf(Character.toUpperCase(word.charAt(i))) :
                        String.valueOf(word.charAt(i))
        ));



    }
}
