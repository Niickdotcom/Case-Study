import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class IntegerofValidation {

    public static void main(String[] args) {

        List<Integer> numbers = Arrays.asList(10, 25, 45, 60, 85, 90, 35);
        //Split into list as list1 = 1 to 40
        //list2 as 40 to 80
        // list3 as more than 80
        // and if value is then sum it for example 10 + 22 = 32;


        List<Integer> IntegerListfrom1to40 =
                numbers.stream().filter(n  -> n >= 1 && n < 40).toList();
        System.out.println("Integer List from 1 to 40 " + IntegerListfrom1to40);
        int returnSum =
                numbers.stream().filter(n -> n >= 1 && n < 40).mapToInt(
                        Integer::intValue
                ).sum();
        System.out.println(" Sum of the numbber  -> " + returnSum);


        List<Integer> IntegerListfrom40to80 =
                numbers.stream().filter(n  -> n >= 40 && n < 80).toList();
        System.out.println("Integer List from 40 to 80 " + IntegerListfrom40to80);
        int returnSum40to80 =
                numbers.stream().filter(n -> n >= 40 && n < 80).mapToInt(
                        Integer::intValue
                ).sum();
        System.out.println(" Sum of the numbber  -> " + returnSum40to80);


        List<Integer> IntegerListfrommorethan80 =
                numbers.stream().filter(n  -> n >= 80).toList();
        System.out.println("Integer List from greate than 80 " + IntegerListfrommorethan80);
        int returnSummore80 =
                numbers.stream().filter(n -> n >= 80).mapToInt(
                        Integer::intValue
                ).sum();
        System.out.println(" Sum of the numbber  -> " + returnSummore80);


        HashMap<Integer,String> maps = new HashMap<>();
        maps.put(1,"Nishith");
        maps.put(2,"Mehta");
        maps.put(3, "Abcd");

        List<String> maptoStringValue = new ArrayList<>(maps.values());

        System.out.println("Map to String -> " + maptoStringValue);


        List<Integer> maptoIntegerValue = new ArrayList<>(maps.keySet());
        System.out.println("Map to Integer -> " + maptoIntegerValue);





    }
}
