package codingPractice300925;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class javaPrac {

    public static void main(String[] args) {
        charletterCheck();
        charletterCheckPart2();
        perfectNumber();
        hashmaptosingleHashMap();
        HashMaptoArrayList();
        LongestString();
        symbols();
    }

    private static void symbols() {

        String symbol = "{[]}";
        Stack<Character> sac = new Stack<>();

        for(char ch : symbol.toCharArray()){
            if(ch == '(' || ch == '{' || ch == '['){
                sac.push(ch);
            } else if(ch == ')' || ch == '}' || ch == ']'){
                if (sac.isEmpty()){
                    System.out.println(" 1 Unbalanced brackets");
                    return;
                }

                char top = sac.pop();
                if(!isMatching(top,ch)){
                    System.out.println(" 2 Unbalanced brackets");
                    return;
                }

            }
        }

        if (sac.isEmpty()) {
            System.out.println("Brackets are balanced");
        } else {
            System.out.println("Unbalanced brackets");
        }
    }

    private static boolean isMatching(char open, char close) {

        return (open == '(' && close == ')') ||
               (open == '{' && close == '}') ||
                (open == '[' && close ==']');
    }

    private static void LongestString() {

        /*
        Question: For the given string such as "aabbbbbcc" print the longest occurring character,index and number of times it occurs.
Ex: longest occurring character is b and length is 5 at index 2.
         */


        String letter = "aabbbbbcc";

        letter.chars().mapToObj(s -> (char) s)
                .collect(Collectors.groupingBy(
                        s -> s, Collectors.counting()
                )).entrySet().stream().filter(st -> st.getValue() > 1 )
                .map(str -> String.valueOf(str.getKey()))
                .collect(Collectors.joining());




    }

    private static void HashMaptoArrayList() {

        HashMap<Integer,String> fir = new HashMap<>();
        fir.put(1,"Nishith");
        fir.put(2,"Ibrahim");


        List<?> mergelist  = new ArrayList<>(fir.entrySet());
        System.out.println("List " + mergelist);
    }

    private static void hashmaptosingleHashMap() {

        HashMap<Integer,String> fir = new HashMap<>();


        fir.put(1,"Nishith");

        HashMap<Integer,String> sec = new HashMap<>();
        sec.put(2,"Ibrahim");


        HashMap<Integer,String> createSingle = new HashMap<>();
        createSingle.putAll(fir);
        createSingle.putAll(sec);

        System.out.println(createSingle);


        createSingle.forEach((k1,k2) ->
                createSingle.merge(k1,k2,((v1,v2) -> v1 + " , " + v2)));












    }

    private static void perfectNumber() {

        System.out.println("Perfect numbers between 1 and 100:");
        for (int num = 1; num <= 100; num++) {
            int sum = 0;
            // Find proper divisors
            for (int i = 1; i < num; i++) {
                if (num % i == 0) {
                    sum += i;
                }
            }
            // Check if number is perfect
            if (sum == num) {
                System.out.println(num);
            }
        }

    }

    private static void charletterCheckPart2() {

        String str = "abc-123+xyz_897^a12";
        String[] splitStr = str.split("[-+_^+]");
        System.out.println(Arrays.toString(splitStr));


        List<String> letters
                = Arrays.stream(splitStr).filter(
                ss -> ss.matches("[a-zA-Z]+")
        ).toList();
        System.out.println(letters);


        List<Integer> onInteger =
                Arrays.stream(splitStr).filter(ss -> ss.matches("[0-9]+"))
                        .map( i -> Integer.valueOf(i)).toList();

        System.out.println(onInteger);


        List<String> alphanumeric =
                Arrays.stream(splitStr).filter(ss -> ss.matches("[a-zA-Z][0-9]+"))
                        .toList();

        System.out.println(alphanumeric);
        
    }

    private static void charletterCheck() {



        String str = "abc-123-xyz-897-a12";

        String[] splStr = str.split("-");
        System.out.println(Arrays.toString(splStr));
        //[abc, 123, xyz, 897, a12]

        List<String> letters
                = Arrays.stream(splStr).filter(
                        ss -> ss.matches("[a-zA-Z]+")
        ).toList();
        System.out.println(letters);


        List<Integer> onInteger =
                Arrays.stream(splStr).filter(ss -> ss.matches("[0-9]+"))
                        .map( i -> Integer.valueOf(i)).toList();

        System.out.println(onInteger);


        List<String> alphanumeric =
                Arrays.stream(splStr).filter(ss -> ss.matches("[a-zA-Z][0-9]+"))
                        .toList();

        System.out.println(alphanumeric);





    //Output: [abc,xyz]
        //[123,897]
        //[a12]

//        matched



    }


}
