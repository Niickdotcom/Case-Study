package codingPractice300925;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Integers {

    public static void main(String[] args) {

        Integer[] s = {5,3,2,6,5,1,2,3,2};


  List<Integer> countmorethanone =      Arrays.stream(s).collect(Collectors.groupingBy(i->i, Collectors.counting()))
                .entrySet().stream().filter(v -> v.getValue() > 1)
                .map(k -> k.getKey()).toList();

        System.out.println("Count more than one --> " + countmorethanone);


        Integer firstnonrepetable =
                Arrays.stream(s).collect(Collectors.groupingBy(i->i,
                        Collectors.counting())).entrySet().stream()
                        .filter(v -> v.getValue() == 1).findFirst().map(k -> k.getKey()).map(Integer::intValue).get();

        System.out.println("First non rep -> " + firstnonrepetable);


        Integer firstnonrepetabledesc =
                Arrays.stream(s).collect(Collectors.groupingBy(i->i,
                                Collectors.counting())).entrySet().stream()
                        .filter(v -> v.getValue()== 1)
                        .map(k -> k.getKey()).sorted(Comparator.reverseOrder()).findFirst().get();

        System.out.println("First non rep -> " + firstnonrepetabledesc);




        //Mutiply and dividing

        Integer total =
                Arrays.stream(s).reduce((a,b) -> a * b).get();

        System.out.println("TOTAL -> " + total);

        List<Integer> totalwidiv =
                Arrays.stream(s).map(v -> total/v).toList();

        System.out.println("new List -> "  + totalwidiv);




    }
}
