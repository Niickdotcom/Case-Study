package codingPractice300925;

import java.util.Stack;

public class BracketChecker {
    public static void main(String[] args) {
        String symbol = "{}[]()";
        Stack<Character> sac = new Stack<>();

        for (char ch : symbol.toCharArray()) {
            if (ch == '(' || ch == '{' || ch == '[') {
                sac.push(ch);
            } else if (ch == ')' || ch == '}' || ch == ']') {
                if (sac.isEmpty()) {
                    System.out.println("Unbalanced brackets");
                    return;
                }
                char top = sac.pop();
                if (!isMatchingPair(top, ch)) {
                    System.out.println("Unbalanced brackets");
                    return;
                }
            }
        }

        if (sac.isEmpty()) {
            System.out.println("Brackets are balanced");
        } else {
            System.out.println("Unbalanced brackets");
        }
        
        
        newBrackerterChecker();
    }

    private static void newBrackerterChecker() {
        System.out.println("newwwwwwwwww");
        String bracketer = "{}[]()";

        Stack<Character> brac = new Stack<>();

        for(char close : bracketer.toCharArray()){
            if(close == '{' || close == '[' || close == '('){
                brac.push(close);
            } else if(close == '}' || close ==']' || close == ')'){
                if(brac.isEmpty()){
                    System.out.println("not match");
                    return;
                }
                char top = brac.pop();
                if(!IsBracketeMatch(top,close)){
                    System.out.println("2 not match");
                    return;
                }
            }
        }

        if(brac.isEmpty()){
            System.out.println("Match");
        } else {
            System.out.println("not match");
        }





    }

    private static boolean IsBracketeMatch(char top, char close) {

        return  (top == '{' && close == '}') ||
                (top == '[' && close == ']') ||
                (top == '(' && close == ')');
    }


    public static boolean isMatchingPair(char open, char close) {
        return (open == '(' && close == ')') ||
                (open == '{' && close == '}') ||
                (open == '[' && close == ']');
    }
}