import java.security.cert.CertPath;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class JavaCodingQuestion {

    public static void main(String[] args) {


        removetheString();

        removetheSpecificcharacterfromString();
        sortInAscendingandDescending();
        repetingString();
        maximumOccuranceCharacter();
        givenStringEvenlistreturnString();
        stringWithSymbol();
//        calling();



    }

    private static void stringWithSymbol() {

        /*
        11) Given an "out" string length 4, such as "<<>>", and a word, return a new string where the word is in the middle of the out string, e.g. "<<word>>".
        Note: use str.substring(i, j) to extract the String starting at index i and going up to but not including index j.
        makeOutWord("<<>>", "Yay") → "<<Yay>>"
        makeOutWord("<<>>", "WooHoo") → "<<WooHoo>>"
        makeOutWord("[[]]", "word") → "[[word]]"
        public String makeOutWord(String out, String word) {
        return out.substring(0,2)+word+out.substring(2,4);
        } */


        String symbol = "<<>>";
        String word = "Yay";
//        op = <<Yay>>

        StringBuilder nn = new StringBuilder();

        nn.append(symbol.substring(0,2))
                    .append(word)
                    .append(symbol.substring(2,4));

        System.out.println("NNN -> " +nn);
    }

    private static void givenStringEvenlistreturnString() {
        /*
        12) Given a string of even length, return the first half. So the string "WooHoo" yields "Woo".
            firstHalf("WooHoo") → "Woo"
            firstHalf("HelloThere") → "Hello"
            firstHalf("abcdef") → "abc"
         */

        String word = "WooHoo";

        int i = word.length()/2;
        StringBuilder newstr = new StringBuilder();
        for (int j = 0; j<i;j++){
            newstr.append(word.charAt(j));
        }
        System.out.println(newstr);

    }

    private static void maximumOccuranceCharacter() {

        /*
        9) Write a Java program to find the maximum occurring character in a string.
            Sample Output:
	        The given string is: test string
	        Max occurring character in the given string is: t
         */


        String val = "test string"; //OP  = t

      String repet = val.chars().mapToObj(c -> (char) c)
                      .collect(
                              Collectors.groupingBy(ss -> ss, LinkedHashMap::new,Collectors.counting())
                      ).entrySet().stream().filter(ss -> ss.getValue() > 1)
                      .map(st -> String.valueOf(st.getKey())).collect(Collectors.joining());

        System.out.println("repet -> " + repet);



    }

    private static void repetingString() {
        /*  Sample Output:
            The given string is: welcome
            The new string is: wweellccoommee  */

        String word = "welcome";
        String[] arrstr = word.split("");
        StringBuilder ss = new StringBuilder(Arrays.toString(arrstr)).repeat(Arrays.toString(arrstr),1);
        System.out.println("Repert -> " + ss);


        String repeteChar = word.chars().mapToObj(c -> (char) c)
                .map(ss1 -> new StringBuffer(ss1).repeat(ss1,2)).collect(Collectors.joining());

        System.out.println(" RepetChar " +repeteChar);


        String rrr = Arrays.stream(word.split("")).map(
                n -> n + n
        ).collect(Collectors.joining());

        System.out.println("aaaa -> " +rrr);
    }

    private static void sortInAscendingandDescending() {


        /*
        6) Write a Java program to sort in ascending and descending order by length of the given array of strings.

Original unsorted colors: [Green, White, Black, Pink, Orange, Blue, Champagne, Indigo, Ivory]

Sorted color (descending order): [Champagne, Orange, Indigo, Green, White, Black, Ivory, Pink, Blue]

Sorted color (ascending order): [Pink, Blue, Green, White, Black, Ivory, Orange, Indigo, Champagne]
         */



        String[] colours = {"Green", "White", "Black", "Pink", "Orange", "Blue", "Champagne", "Indigo", "Ivory"};
//        Sorted color (descending order) ->  Sorted color (descending order): [Champagne, Orange, Indigo, Green, White, Black, Ivory, Pink, Blue]
        List<String> descndingOrder =
                Arrays.stream(colours).sorted(Comparator.comparingInt(String::length).reversed())
                        .toList();
        System.out.println("Descending Order  - > " + descndingOrder);


        List<String> ascendingOrder =
                Arrays.stream(colours).sorted(Comparator.comparingInt(String::length))
                        .toList();
        System.out.println("ASC Order  - > " + ascendingOrder);




    }

    private static void removetheSpecificcharacterfromString() {
        /*
Original string:
abcdefabcdeabcdaaa

remove char from given string :  "a"

Second string:
bcdefbcdebcd
         */



        String str = "abcdefabcdeabcdaaa";
        String remchar = "a";
        String op  = str.chars().mapToObj(c -> (char) c)
                .filter(st -> st != remchar.charAt(0))
                .map(sts ->  String.valueOf(sts))
                .collect(Collectors.joining());

        System.out.println("Opp-> " +op);




        String result = str.chars()
                .mapToObj(c -> (char) c)
                .filter(c -> c != remchar.charAt(0))
                .map(String::valueOf)
                .collect(Collectors.joining());

        System.out.println(result);


    }

    private static void removetheString() {

        /*
        4) Write a Java program that removes a specified word from a given text. Return the new string.
            ("Exercises Practice Solution", " Solution") -> "Exercises Practice"
            ("Red Green Blue", "Green") -> "Red Blue"
            ("Java Number Exercises”, “Java”) -> "Number Exercises"
         */


        String wrd1 = "Exercises Practice Solution"; //Solution
        String remove = "Exercises Practice ";
        String output = "";
        String[] wrdarr = wrd1.split(" ");
        for(int i = 0; i < wrdarr.length; i ++){
            if(!remove.matches(wrdarr[i])){
                output = wrdarr[i];
            }
        }
        System.out.println(output);

        String wrd2 = "Red Green Blue"; //Solution
        String remove2 = "Red Blue";
        String output2 = "";
        String[] wrdarr2 = wrd2.split(" ");
        for(int i = 0; i < wrdarr2.length; i ++){
            if(!remove2.matches(wrdarr2[i])){
                output2 = wrdarr2[i];
            }
        }
        System.out.println(output2);

    }
}
