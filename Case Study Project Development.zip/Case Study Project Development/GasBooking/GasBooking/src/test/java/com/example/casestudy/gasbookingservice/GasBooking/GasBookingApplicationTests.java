package com.example.casestudy.gasbookingservice.GasBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GasBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
