package com.example.casestudy.gasbookingservice.Service;

import com.example.casestudy.gasbookingservice.Entity.Gasbooking;
import com.example.casestudy.gasbookingservice.Repository.Gasrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Gasservice {

    @Autowired
    private Gasrepository gasrepo;

    public Gasbooking insertGasBooking(Gasbooking insertGasBooking) {
        return gasrepo.save(insertGasBooking);
    }

    public Gasbooking updateGasBooking(Gasbooking updateGasBooking) {
        return  gasrepo.save(updateGasBooking);
    }

    public String  deleteGasBooking(Long gasBookingId) {

        {
            String message = "GasBooking "+ gasBookingId +" Deleted Sucessfully ";
            Optional<Gasbooking> getGasBookingDetails = gasrepo.findById(gasBookingId);

            if(!getGasBookingDetails.isEmpty()){
                Gasbooking existing = new Gasbooking();

                existing.setGasBookingId(getGasBookingDetails.get().getGasBookingId());
                existing.setCustomerID(getGasBookingDetails.get().getCustomerID());
                existing.setBookingDate(getGasBookingDetails.get().getBookingDate());
                existing.setStatus(false);
                existing.setBillAmount(getGasBookingDetails.get().getBillAmount());
                gasrepo.save(existing);

            }
            return message;

        }


    }

    public Gasbooking findByCustomerID(Long customerID) {
        return gasrepo.findByCustomerID(customerID);
    }

    public List<Gasbooking> findAllBookingDetails(Long customerID) {
        List<Gasbooking> getAllBookingByCustomerID
                  = gasrepo.findAll().stream().filter(
                          gas -> gas.getCustomerID().equals(customerID)
        ).toList();

        return  getAllBookingByCustomerID;

    }
}
