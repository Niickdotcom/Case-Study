package com.example.casestudy.gasbookingservice.Entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
public class Gasbooking {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long gasBookingId;
    Long customerID;
    LocalDate bookingDate;
    Boolean status;
    Double billAmount;
    Long customerMobileNumber;

    public Long getCustomerMobileNumber() {
        return customerMobileNumber;
    }

    public void setCustomerMobileNumber(Long customerMobileNumber) {
        this.customerMobileNumber = customerMobileNumber;
    }

    public Long getGasBookingId() {
        return gasBookingId;
    }

    public void setGasBookingId(Long gasBookingId) {
        this.gasBookingId = gasBookingId;
    }

    public Long getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Long customerID) {
        this.customerID = customerID;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Double getBillAmount() {
        return billAmount;
    }

    public void setBillAmount(Double billAmount) {
        this.billAmount = billAmount;
    }
}
