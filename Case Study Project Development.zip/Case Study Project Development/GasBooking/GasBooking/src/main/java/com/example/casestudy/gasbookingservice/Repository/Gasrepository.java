package com.example.casestudy.gasbookingservice.Repository;

import com.example.casestudy.gasbookingservice.Entity.Gasbooking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Gasrepository extends JpaRepository<Gasbooking,Long> {

    Gasbooking findByCustomerID(Long customerID);
}
