package com.example.casestudy.gasbookingservice.Controller;

import com.example.casestudy.gasbookingservice.Entity.Gasbooking;
import com.example.casestudy.gasbookingservice.Service.Gasservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/gascontroller")
public class GasController {

    @Autowired
    private Gasservice gasservice;

    @PostMapping("/insertGasBooking")
    public Gasbooking insertGasBooking(
            @RequestBody Gasbooking insertGasBooking,
            @RequestHeader("customerID") Long customerID) {

        System.out.println("here");
        insertGasBooking.setCustomerID(customerID);
        insertGasBooking.setBookingDate(LocalDate.now());
        insertGasBooking.setStatus(false); // pending
        insertGasBooking.setBillAmount(999.0);

        return gasservice.insertGasBooking(insertGasBooking);

    }

    @PutMapping("/updateGasBooking")
    public Gasbooking updateGasBooking(@RequestBody Gasbooking updateGasBooking){
        return  gasservice.updateGasBooking(updateGasBooking);
    }

    @DeleteMapping("/deleteGasBooking/{gasBookingId}")
    public  String deleteGasBooking(@PathVariable Long gasBookingId){
        return gasservice.deleteGasBooking(gasBookingId);
    }

    @GetMapping("/getGasBooking/{customerID}")
    public  Gasbooking getGasBookingServiceByID(@PathVariable Long customerID){
        return  gasservice.findByCustomerID(customerID);
    }

    @GetMapping("/getBookingDetailsbyCustomer/{customerID}")
    public List<Gasbooking> getBookingDetailsbyCustomer(@PathVariable Long customerID){
        return  gasservice.findAllBookingDetails(customerID);
    }



}
