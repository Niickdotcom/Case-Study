package com.example.gas.authservice.authapplication.Controller;

import com.example.gas.authservice.authapplication.Entity.User;
import com.example.gas.authservice.authapplication.Repository.AuthUserRepository;
import com.example.gas.authservice.authapplication.security.JwtUtil;
import jakarta.validation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;


@RestController
@RequestMapping("/auth")
public class AuthController {


    @Autowired
    private AuthUserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();

    @Autowired
    private final Validator validator = factory.getValidator();


    @PostMapping("/register")
    private String registerUser(@RequestHeader("username") String username, @RequestHeader("password") String password){
        System.out.println("aaaaaa");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

        Set<ConstraintViolation<User>> violations = validator.validate(user);
        if(!violations.isEmpty()){
            return violations.iterator().next().getMessage();
        }

        if(userRepository.findByUsername(user.getUsername()).isPresent()){
            return  "Username already Exist";
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRoles("Customer");
        userRepository.save(user);
        return "user Register Sucessfully";
    }

    @PostMapping("/login")
    private ResponseEntity<Map<String, String>> login(@RequestHeader("username") String username,
                                                      @RequestHeader("password") String password){

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

        Set<ConstraintViolation<User>> violation = validator.validate(user);
        if(!violation.isEmpty()){
            String errorMessage = violation.iterator().next().getMessage();

            Map<String, String> response = new HashMap<>();
            response.put("error", errorMessage);

            return ResponseEntity.badRequest().body(response);

        }

        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            username,password
                    )
            );

        } catch (Exception ee){
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Invalid " + ee.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
        String tokend =  jwtUtil.generateToken(username);
        System.out.println(tokend);
        Map<String, String> response = new HashMap<>();
        response.put("token", tokend);

        return ResponseEntity.ok(response);


    }

    @PostMapping("/validate")
    public ResponseEntity<Boolean> validateToken(@RequestHeader("Authorization") String token){
        boolean isValidToken = jwtUtil.validateToken(token.replace("Bearer ",""));
        return ResponseEntity.ok(isValidToken);
    }


}
