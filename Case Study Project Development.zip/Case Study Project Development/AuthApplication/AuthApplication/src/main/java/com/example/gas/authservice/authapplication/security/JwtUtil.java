package com.example.gas.authservice.authapplication.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.util.Date;


@Component
public class JwtUtil {

    private static final String SECRET = System.getenv().getOrDefault("JWT_SECRET", "qwertyuiopasdfghjklzxcvbnmmnbvcxzlkjhgfdsapoiuytrewq");
    private static final long expiration = 1000 * 60 * 60;

    @PostConstruct
    public void init(){

    }


    public String generateToken(String username) {

        System.out.println("Inside this generate" + username);

        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(SignatureAlgorithm.HS256, SECRET)
                .compact();
    }

    public String extractUsername(String token){
        return Jwts.parserBuilder().setSigningKey(SECRET).build().parseClaimsJws(token).getBody().getSubject();
    }

    public boolean validateToken(String token, String username) {
        return extractUsername(token).equals(username) && !isTokenExpiry(token);
    }

    public boolean validateToken(String token) {
        return !extractUsername(token).isEmpty() && !isTokenExpiry(token);
    }

    public boolean isTokenExpiry(String token){
        return Jwts.parserBuilder()
                .setSigningKey(SECRET)
                .build().parseClaimsJws(token)
                .getBody().getExpiration().before(new Date());
    }

    public String getUsername(String token) {
        return
                Jwts.parserBuilder().setSigningKey(SECRET.getBytes()).build()
                        .parseClaimsJws(token).getBody().getSubject();
    }

}
