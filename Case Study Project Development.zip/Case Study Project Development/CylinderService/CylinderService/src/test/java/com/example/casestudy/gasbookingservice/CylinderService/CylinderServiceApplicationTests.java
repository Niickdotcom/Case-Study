package com.example.casestudy.gasbookingservice.CylinderService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CylinderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
