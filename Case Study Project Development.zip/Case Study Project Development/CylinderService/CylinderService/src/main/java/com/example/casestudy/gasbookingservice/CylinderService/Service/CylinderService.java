package com.example.casestudy.gasbookingservice.CylinderService.Service;


import com.example.casestudy.gasbookingservice.CylinderService.Entity.Cylinder;
import com.example.casestudy.gasbookingservice.CylinderService.Repository.CylinderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CylinderService {

    @Autowired
    public CylinderRepository cylinderRepo;


    public Cylinder insertCylinderDetails(Cylinder cylinderDetailsInsert) {
        return cylinderRepo.save(cylinderDetailsInsert);
    }

    public Cylinder updateCylinderDetails(Cylinder cylionderDetailsUpdate) {
        return  cylinderRepo.save(cylionderDetailsUpdate);
    }

    public String deleteCylinderById(Long cylinderID) {
        String message = "Cylinder "+ cylinderID +" Deleted Sucessfully ";
        Optional<Cylinder> getCylinderDetails = cylinderRepo.findById(cylinderID);

        if(!getCylinderDetails.isEmpty()){
            Cylinder existing = new Cylinder();
            existing.setCylinderID(getCylinderDetails.get().getCylinderID());
            existing.setCylinderType(getCylinderDetails.get().getCylinderType());
            existing.setCylinderType(getCylinderDetails.get().getCylinderType());
            existing.setCylinderWeight(getCylinderDetails.get().getCylinderWeight());
            existing.setStrapColor(getCylinderDetails.get().getStrapColor());
            existing.setPrice(getCylinderDetails.get().getPrice());
            existing.setCylinderActive(0);
            cylinderRepo.save(existing);
        }


        return message;
    }

    public List<Cylinder> viewCylinderByType(Long cylinderType) {
        return cylinderRepo.findCylinderByCylinderType(cylinderType);
    }
}
