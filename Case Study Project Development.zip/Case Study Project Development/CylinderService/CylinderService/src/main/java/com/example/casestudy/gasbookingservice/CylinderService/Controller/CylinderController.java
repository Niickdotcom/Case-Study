package com.example.casestudy.gasbookingservice.CylinderService.Controller;

import com.example.casestudy.gasbookingservice.CylinderService.Entity.Cylinder;
import com.example.casestudy.gasbookingservice.CylinderService.Service.CylinderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/cylinder")
public class CylinderController {

    @Autowired
    private CylinderService cylinderService;

    @PostMapping("/addCylinderDetails")
    public Cylinder insertCylinderDetails(@RequestBody Cylinder cylinderDetailsInsert){
        return cylinderService.insertCylinderDetails(cylinderDetailsInsert);
    }

    @PutMapping("/updateCylinderDetails")
    public Cylinder updateCylinderDetails(@RequestBody Cylinder cylionderDetailsUpdate){
        return cylinderService.updateCylinderDetails(cylionderDetailsUpdate);
    }

    @DeleteMapping("/deleteCylinderDetails/{cylinderID}")
    public String deletCylinderDetails(@PathVariable Long cylinderID){
        return cylinderService.deleteCylinderById(cylinderID);
    }

    @GetMapping("/getCylinderListByType/{cylinderType}")
    public List<Cylinder> getCylinderDetailsByType(@PathVariable Long cylinderType){
        List<Cylinder> CylinderByID = cylinderService.viewCylinderByType(cylinderType);
        return  CylinderByID;
    }


}
