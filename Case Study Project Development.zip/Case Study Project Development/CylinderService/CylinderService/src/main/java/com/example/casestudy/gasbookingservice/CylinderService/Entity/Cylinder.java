package com.example.casestudy.gasbookingservice.CylinderService.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Cylinder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long cylinderID;
    Long cylinderType;
    Double cylinderWeight;
    String strapColor;
    Double price;
    int cylinderActive;

    public int getCylinderActive() {
        return cylinderActive;
    }

    public void setCylinderActive(int cylinderActive) {
        this.cylinderActive = cylinderActive;
    }

    public Long getCylinderID() {
        return cylinderID;
    }

    public void setCylinderID(Long cylinderID) {
        this.cylinderID = cylinderID;
    }

    public Long getCylinderType() {
        return cylinderType;
    }

    public void setCylinderType(Long cylinderType) {
        this.cylinderType = cylinderType;
    }

    public Double getCylinderWeight() {
        return cylinderWeight;
    }

    public void setCylinderWeight(Double cylinderWeight) {
        this.cylinderWeight = cylinderWeight;
    }

    public String getStrapColor() {
        return strapColor;
    }

    public void setStrapColor(String strapColor) {
        this.strapColor = strapColor;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
