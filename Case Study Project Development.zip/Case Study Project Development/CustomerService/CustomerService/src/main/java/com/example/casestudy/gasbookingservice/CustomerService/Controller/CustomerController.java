package com.example.casestudy.gasbookingservice.CustomerService.Controller;

import com.example.casestudy.gasbookingservice.CustomerService.Entity.Customer;
import com.example.casestudy.gasbookingservice.CustomerService.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/customerController")
public class CustomerController {

    @Autowired
    private CustomerService custService;

//    public CustomerController(CustomerService custService){
//        this.custService  = custService;
//    }



    @PostMapping("/addCustomerDetails")
    public Customer insertCustomerDetails(@RequestBody Customer custDetailsInsert){
        return custService.insertCustDetails(custDetailsInsert);
    }

    @PutMapping("/updateCustomerDetails")
    public Customer updateCustomerDetails(@RequestBody Customer custDetailsUpdate){
        return custService.updateCustomerDetails(custDetailsUpdate);
    }

    @DeleteMapping("/deleteCustomerDetails/{customerID}")
    public String deletCustomerDetails(@PathVariable Long customerID){
        System.out.println("Inside Delete");
        return custService.deleteCustomerDetailsById(customerID);
    }

    @GetMapping("/getCustomerList")
    public List<Customer> getCustomerDetails(){
        return (List<Customer>) custService.getAllCustomerDetails();
    }

        @GetMapping("/getCustomerListByID/{customerID}")
    public Optional<Customer> getCustomerDetailsByID(@PathVariable Long customerID){
        System.out.println("ABCD");
        Optional<Customer> CustomerByID = custService.getCustomerDetailsById(customerID);
        return  CustomerByID;
    }

    @PutMapping("/validatingCustomer")
    public  ResponseEntity<?> validateCustomerDetailsById(String userName, String Password){
        return null;
    }
}
