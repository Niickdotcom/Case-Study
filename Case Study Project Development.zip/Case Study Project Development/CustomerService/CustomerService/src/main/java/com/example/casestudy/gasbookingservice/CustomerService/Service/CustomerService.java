package com.example.casestudy.gasbookingservice.CustomerService.Service;

import com.example.casestudy.gasbookingservice.CustomerService.Entity.Customer;
import com.example.casestudy.gasbookingservice.CustomerService.Repository.CustomerRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerService {

  private CustomerRepository custRepo;

  public  CustomerService(CustomerRepository custRepo){
      this.custRepo = custRepo;
  }


    public Customer insertCustDetails(Customer custDetailsInsert) {
     return custRepo.save(custDetailsInsert);
    }

    public List<Customer> getAllCustomerDetails() {
      return custRepo.findAll();
    }

    public Optional<Customer> getCustomerDetailsById(Long customerID) {
      return custRepo.findById(customerID);
    }

    public Customer updateCustomerDetails(Customer custDetailsUpdate) {
      return  custRepo.save(custDetailsUpdate);
    }

    public String deleteCustomerDetailsById(Long customerID) {
      String message = "Customer "+ customerID +" Deleted Sucessfully ";
      Optional<Customer> getCustomerDetails = custRepo.findById(customerID);

      if(!getCustomerDetails.isEmpty()){
          Customer existing = new Customer();

          existing.setCustomerID(getCustomerDetails.get().getCustomerID());
          existing.setAccountNo(getCustomerDetails.get().getAccountNo());
          existing.setBankID(getCustomerDetails.get().getBankID());
          existing.setCylinderID(getCustomerDetails.get().getCylinderID());
          existing.setPanNumber(getCustomerDetails.get().getPanNumber());
          existing.setBankID(getCustomerDetails.get().getBankID());
          existing.setIfciNumber(getCustomerDetails.get().getIfciNumber());
          existing.setCustomerActive(0);

         custRepo.save(existing);

      }
      return message;

    }
}
