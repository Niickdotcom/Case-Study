package com.example.casestudy.gasbookingservice.CustomerService.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long customerID;

    Long cylinderID;

    Long bankID;

    Long accountNo;

    String ifciNumber;

    String panNumber;

    int customerActive;


    public Long getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Long customerID) {
        this.customerID = customerID;
    }

    public Long getCylinderID() {
        return cylinderID;
    }

    public void setCylinderID(Long cylinderID) {
        this.cylinderID = cylinderID;
    }

    public Long getBankID() {
        return bankID;
    }

    public void setBankID(Long bankID) {
        this.bankID = bankID;
    }

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public String getIfciNumber() {
        return ifciNumber;
    }

    public void setIfciNumber(String ifciNumber) {
        this.ifciNumber = ifciNumber;
    }

    public String getPanNumber() {
        return panNumber;
    }

    public void setPanNumber(String panNumber) {
        this.panNumber = panNumber;
    }

    public int getCustomerActive() {
        return customerActive;
    }

    public void setCustomerActive(int customerActive) {
        this.customerActive = customerActive;
    }
}
